const serverless = require('serverless-http');
const { spawn } = require('child_process');
const express = require('express');
const path = require('path');

// Create express app
const app = express();

// Serve static files
app.use(express.static(path.join(__dirname, '../../static')));

// Proxy all requests to the Flask app
app.all('*', (req, res) => {
  // Start the Flask app as a child process
  const flask = spawn('python', ['../../app.py']);
  
  // Handle Flask output
  flask.stdout.on('data', (data) => {
    console.log(`Flask stdout: ${data}`);
  });
  
  flask.stderr.on('data', (data) => {
    console.error(`Flask stderr: ${data}`);
  });
  
  // Forward the request to Flask
  res.send('Flask app is running');
});

// Export the serverless function
module.exports.handler = serverless(app);