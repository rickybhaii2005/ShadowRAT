# RemoteBatControl - Remote Administration Tool

A comprehensive web-based system monitoring and remote administration tool built with Flask. This application provides real-time system monitoring, file management, remote command execution, and system control capabilities through a secure web interface.

## 🚀 Features

### System Monitoring
- **Real-time Metrics**: CPU usage, memory consumption, disk space, load averages
- **Process Management**: View running processes, search and filter capabilities
- **Network Monitoring**: Interface statistics, I/O metrics, connection counts
- **System Information**: Detailed hardware and OS information

### Remote Administration
- **Command Execution**: Execute safe system commands remotely with output display
- **System Power Control**: Remote restart, shutdown, and logout with safety delays
- **File Management**: Upload, download, and manage files through web interface
- **Log Viewer**: Access and download system logs with syntax highlighting

### Security Features
- **Authentication**: Username/password login system
- **Session Management**: Secure session handling with timeouts
- **Command Restrictions**: Only safe, predefined commands allowed
- **File Type Restrictions**: Limited file upload types for security
- **Action Logging**: All administrative actions are logged

### Network Capabilities
- **Device Discovery**: Scan and identify devices on local networks
- **Port Scanning**: Check for open ports on discovered devices
- **Remote Deployment**: Deploy monitoring tools to target devices
- **Cross-Network Control**: Manage devices across different networks

## 📋 Requirements

- Python 3.7+
- Flask
- psutil
- Werkzeug
- Additional dependencies in requirements.txt

## 🛠️ Installation

### Local Installation

1. **Clone or download** this repository
2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```
3. **Run the application**:
   ```bash
   python app.py
   ```

### Packaged Software Installation

For a ready-to-use software package:

1. **Package the application**:
   ```bash
   package_app.bat
   ```
   Choose your preferred packaging option (single executable, directory, etc.)

2. **Install on target system**:
   - Run `install.bat` from the packaged distribution
   - Follow the on-screen instructions

3. **Access the web interface**:
   - Open a web browser and navigate to `http://localhost:5000`
   - Log in with the default credentials (see below)

## 🔐 Default Credentials

- **Username**: `subhashbswkrm`
- **Password**: `Sb13579@@@`

**IMPORTANT**: Change these credentials immediately after installation for security.

## 📦 Software Packaging

This project includes tools to package the application into a standalone executable:

### Packaging Options

1. **Single Executable** (Recommended for easy distribution)
   - Creates a single .exe file that contains everything needed
   - Simplest for end-users to run

2. **Directory with Dependencies**
   - Creates a directory with the executable and all dependencies
   - Better performance but requires distributing the entire folder

3. **Console Mode**
   - Creates a single executable that shows a console window
   - Useful for debugging and seeing application output

### Packaging Instructions

1. Run `package_app.bat`
2. Select your preferred packaging option
3. Wait for the packaging process to complete
4. Find the packaged software in the `dist` directory

## 📚 Documentation

- **SOFTWARE_README.md**: Instructions for packaging, installing, and using the software
- **KEYLOGGER_README.md**: Information about the keylogger component

## ⚠️ Legal and Ethical Considerations

This software is designed for legitimate system administration and monitoring purposes. Using this software to monitor systems without proper authorization may violate privacy laws and regulations.

- Only use on systems you own or have explicit permission to monitor
- Inform users if their systems are being monitored
- Comply with all applicable laws and regulations regarding system monitoring

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.