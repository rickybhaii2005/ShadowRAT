#!/usr/bin/env python3
"""
RemoteBatControl File Verification Script

This script verifies that all necessary files are present before packaging the application.
"""

import os
import sys

def check_file(file_path, required=True):
    """Check if a file exists and print status"""
    exists = os.path.isfile(file_path)
    status = "✓" if exists else "✗"
    requirement = "Required" if required else "Optional"
    print(f"{status} {file_path} [{requirement}]")
    return exists

def check_directory(dir_path, required=True):
    """Check if a directory exists and print status"""
    exists = os.path.isdir(dir_path)
    status = "✓" if exists else "✗"
    requirement = "Required" if required else "Optional"
    print(f"{status} {dir_path}/ [{requirement}]")
    return exists

def main():
    print("RemoteBatControl File Verification")
    print("=================================")
    
    # Get the current directory
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Required files
    required_files = [
        "app.py",
        "main.py",
        "system_monitor.py",
        "client_handler.py",
        "requirements.txt",
        "setup.py",
        "package_app.bat"
    ]
    
    # Required directories
    required_dirs = [
        "templates",
        "static",
        "uploads"
    ]
    
    # Optional files
    optional_files = [
        "app_icon.svg",
        "stealth_keylogger.py",
        "deploy_keylogger.py",
        "network_scanner.py",
        "qr_generator.py"
    ]
    
    # Check required files
    print("\nChecking required files:")
    missing_required_files = 0
    for file_name in required_files:
        file_path = os.path.join(current_dir, file_name)
        if not check_file(file_path, required=True):
            missing_required_files += 1
    
    # Check required directories
    print("\nChecking required directories:")
    missing_required_dirs = 0
    for dir_name in required_dirs:
        dir_path = os.path.join(current_dir, dir_name)
        if not check_directory(dir_path, required=True):
            missing_required_dirs += 1
    
    # Check optional files
    print("\nChecking optional files:")
    missing_optional_files = 0
    for file_name in optional_files:
        file_path = os.path.join(current_dir, file_name)
        if not check_file(file_path, required=False):
            missing_optional_files += 1
    
    # Print summary
    print("\nVerification Summary:")
    print(f"Required files: {len(required_files) - missing_required_files}/{len(required_files)} present")
    print(f"Required directories: {len(required_dirs) - missing_required_dirs}/{len(required_dirs)} present")
    print(f"Optional files: {len(optional_files) - missing_optional_files}/{len(optional_files)} present")
    
    # Check if all required files and directories are present
    if missing_required_files == 0 and missing_required_dirs == 0:
        print("\nAll required files and directories are present. Ready for packaging!")
        return 0
    else:
        print("\nSome required files or directories are missing. Please check the list above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())