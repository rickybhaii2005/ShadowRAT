#!/usr/bin/env python3
"""
RemoteBatControl Packaging Script

This script packages the RemoteBatControl application into an executable using PyInstaller.
It creates a standalone executable that can be distributed and run on Windows systems.
"""

import os
import sys
import subprocess
import shutil
import tempfile
import argparse
import platform

def check_dependencies():
    """Check and install required dependencies"""
    print("[*] Checking dependencies...")
    
    # Check if PyInstaller is installed
    try:
        subprocess.check_call([sys.executable, "-m", "PyInstaller", "--version"], 
                             stdout=subprocess.DEVNULL, 
                             stderr=subprocess.DEVNULL)
        print("[+] PyInstaller is already installed")
    except (subprocess.SubprocessError, FileNotFoundError):
        print("[*] Installing PyInstaller...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])
        print("[+] PyInstaller installed successfully")
    
    # Install required packages from requirements.txt
    print("[*] Installing required packages...")
    requirements_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "requirements.txt")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", requirements_path])
    print("[+] All dependencies installed successfully")

def create_executable(output_name="RemoteBatControl", one_file=True, console=True, icon=None):
    """Create an executable version of the application"""
    print(f"[*] Creating {output_name} executable...")
    
    # Get the current directory
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Create a temporary directory for building
    temp_dir = tempfile.mkdtemp()
    try:
        # Prepare PyInstaller command with platform-specific path separators
        separator = ';' if platform.system() == 'Windows' else ':'
        
        pyinstaller_cmd = [
            sys.executable, "-m", "PyInstaller",
            "--name", output_name,
            "--add-data", f"{os.path.join(current_dir, 'templates')}{separator}templates",
            "--add-data", f"{os.path.join(current_dir, 'static')}{separator}static",
            "--add-data", f"{os.path.join(current_dir, 'uploads')}{separator}uploads",
        ]
        
        # Add optional arguments
        if one_file:
            pyinstaller_cmd.append("--onefile")
        else:
            pyinstaller_cmd.append("--onedir")
            
        if not console:
            pyinstaller_cmd.append("--windowed")
            
        # Use default icon if none provided
        if not icon and os.path.exists(os.path.join(current_dir, 'app_icon.svg')):
            # Convert SVG to ICO if possible
            try:
                from cairosvg import svg2png
                from PIL import Image
                
                # Create a temporary directory for icon conversion
                icon_temp_dir = tempfile.mkdtemp()
                svg_path = os.path.join(current_dir, 'app_icon.svg')
                png_path = os.path.join(icon_temp_dir, 'app_icon.png')
                ico_path = os.path.join(icon_temp_dir, 'app_icon.ico')
                
                # Convert SVG to PNG
                svg2png(url=svg_path, write_to=png_path, output_width=256, output_height=256)
                
                # Convert PNG to ICO
                img = Image.open(png_path)
                img.save(ico_path, format='ICO', sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
                
                icon = ico_path
                print(f"[+] Created icon from SVG: {ico_path}")
            except ImportError:
                print("[!] Warning: cairosvg or PIL not installed. Using default icon.")
                icon = None
            except Exception as e:
                print(f"[!] Warning: Failed to convert SVG to ICO: {e}")
                icon = None
        
        if icon:
            pyinstaller_cmd.extend(["--icon", icon])
        
        # Add the main script
        pyinstaller_cmd.append(os.path.join(current_dir, "main.py"))
        
        # Run PyInstaller
        subprocess.check_call(pyinstaller_cmd)
        
        # Copy additional files to the dist directory
        dist_dir = os.path.join(current_dir, "dist")
        if not one_file:
            dist_dir = os.path.join(dist_dir, output_name)
            
        # Create a README file in the dist directory
        with open(os.path.join(dist_dir, "README.txt"), "w") as f:
            f.write("""RemoteBatControl - Remote Administration Tool

This application provides system monitoring and remote administration capabilities.

To start the application:
1. Double-click the RemoteBatControl executable
2. Access the web interface at http://localhost:5000
3. Login with the default credentials:
   Username: subhashbswkrm
   Password: Sb13579@@@

WARNING: This tool provides administrative access to your system.
Only use on trusted networks with strong authentication.
""")
        
        print(f"[+] Executable created successfully in the 'dist' directory")
        print(f"[+] You can find your executable at: {os.path.join(dist_dir, output_name + ('.exe' if sys.platform == 'win32' else ''))}")
        return True
    except Exception as e:
        print(f"[!] Error creating executable: {e}")
        return False
    finally:
        # Clean up the temporary directory
        shutil.rmtree(temp_dir)

def main():
    # Parse command line arguments
    parser = argparse.ArgumentParser(description="Package RemoteBatControl into an executable")
    parser.add_argument("--name", default="RemoteBatControl", help="Name of the output executable")
    parser.add_argument("--onedir", action="store_true", help="Create a directory containing the executable instead of a single file")
    parser.add_argument("--console", action="store_true", help="Show console window when running the executable")
    parser.add_argument("--icon", help="Path to an icon file (.ico) for the executable")
    parser.add_argument("--install-deps", action="store_true", help="Install additional dependencies for icon conversion")
    args = parser.parse_args()
    
    # Install additional dependencies if requested
    if args.install_deps:
        print("[*] Installing additional dependencies for icon conversion...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "cairosvg", "pillow"])
            print("[+] Additional dependencies installed successfully")
        except Exception as e:
            print(f"[!] Error installing additional dependencies: {e}")
            print("[!] Icon conversion may not work properly")
    
    # Check and install dependencies
    check_dependencies()
    
    # Create the executable
    create_executable(
        output_name=args.name,
        one_file=not args.onedir,
        console=args.console,
        icon=args.icon
    )

if __name__ == "__main__":
    main()