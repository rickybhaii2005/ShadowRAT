# System Monitor Dashboard - Remote Administration

## Overview
This is an enhanced Flask-based web application that provides comprehensive real-time system monitoring and remote administration capabilities. The application includes secure authentication, remote command execution, file management, system control, and monitoring through a responsive web interface. It uses psutil for system data collection and Bootstrap for the frontend interface.

## User Preferences
- Preferred communication style: Simple, everyday language
- Username: subhashbswkrm
- Password: Sb13579@@@
- Enhanced visual design with gradient themes and modern UI
- Cross-platform accessibility (Windows, Android, mobile browsers)
- AnyDesk-like functionality for complete device control

## System Architecture
The application follows a simple MVC architecture pattern with Flask as the web framework:

- **Frontend**: HTML templates with Bootstrap CSS framework and Chart.js for data visualization
- **Backend**: Flask web server with Python-based system monitoring utilities
- **Data Collection**: psutil library for cross-platform system and process monitoring
- **Styling**: Bootstrap 5 with custom CSS and Font Awesome icons
- **Client-side**: JavaScript for real-time updates and interactive features

## Key Components

### Backend Components
1. **app.py**: Main Flask application with enhanced route handlers
   - Authentication system with login/logout
   - Dashboard route for system overview
   - Process monitoring endpoint
   - Network monitoring endpoint
   - System logs viewer with download capability
   - Remote control panel for system administration
   - File manager for upload/download operations
   - REST API endpoints for real-time statistics and control
   - Secure command execution with safety restrictions
   - System power control (restart/shutdown/logout)

2. **system_monitor.py**: Core monitoring functionality
   - SystemMonitor class for data collection
   - Cross-platform system information gathering
   - Process and network statistics
   - Log file access and parsing

3. **main.py**: Application entry point for development server

### Frontend Components
1. **Templates**: Jinja2 HTML templates
   - base.html: Common layout and navigation with logout
   - login.html: Secure authentication interface
   - dashboard.html: Main system overview page with real-time charts
   - processes.html: Process monitoring interface with search
   - network.html: Network statistics display with charts
   - logs.html: System log viewer with download and highlighting
   - remote_control.html: Remote administration panel
   - file_manager.html: File upload/download interface

2. **Static Assets**:
   - custom.css: Dashboard-specific styling
   - dashboard.js: Client-side utilities and helper functions

## Data Flow
1. **Authentication**: Session-based authentication with login protection
2. **System Data Collection**: psutil library gathers system metrics and status
3. **Data Processing**: SystemMonitor class formats and structures the data
4. **Command Execution**: Secure command execution with safety restrictions
5. **File Operations**: Upload/download file management with security validation
6. **API Layer**: Protected Flask routes serve HTML pages and JSON API endpoints
7. **Frontend Display**: Templates render data with real-time JavaScript updates
8. **User Interaction**: Navigation between monitoring and administration views
9. **System Control**: Remote administration capabilities with safety measures

## External Dependencies
- **psutil**: Cross-platform system and process monitoring
- **Flask**: Web framework for Python
- **Bootstrap 5**: Frontend CSS framework via CDN
- **Chart.js**: JavaScript charting library via CDN
- **Font Awesome**: Icon library via CDN

The application relies on CDN-hosted resources for frontend dependencies, making it lightweight and easy to deploy.

## Deployment Strategy
The application supports both development and production deployment:
- **Development Server**: Flask's built-in development server for testing
- **Production Server**: Gunicorn WSGI server for production use
- **Host Configuration**: Binds to 0.0.0.0:5000 for network access
- **Authentication**: Session-based login system with configurable credentials
- **File Management**: Upload directory with security restrictions
- **Environment Variables**: SESSION_SECRET for secure session management

### Windows Auto-Startup
- **Batch Scripts**: start_monitor.bat for manual startup
- **Auto-Start Setup**: setup_autostart.bat for Windows Task Scheduler configuration
- **Network Discovery**: Automatic IP address detection and display
- **Service Integration**: Runs as Windows scheduled task for boot startup

### Security Considerations
- **Command Restrictions**: Only predefined safe commands allowed
- **File Type Validation**: Restricted file upload types
- **Session Management**: Secure authentication with timeout
- **Network Security**: Recommended firewall and VPN usage
- **Access Logging**: All administrative actions logged

## Architecture Decisions

### Technology Choices
- **Flask over Django**: Chosen for simplicity and lightweight nature suitable for a monitoring and administration dashboard
- **psutil**: Selected for cross-platform compatibility and comprehensive system monitoring capabilities
- **Bootstrap with Dark Theme**: Provides responsive design and consistent UI components optimized for monitoring interfaces
- **Session-based Authentication**: Simple but secure authentication system suitable for single-user or small team use
- **Werkzeug Security**: Used for secure file handling and upload validation
- **Template-based rendering**: Server-side rendering for initial page loads with JavaScript for real-time updates and administration features

### Design Patterns
- **MVC Pattern**: Clear separation between data collection, business logic, and presentation
- **Modular Design**: SystemMonitor class isolates monitoring logic from web framework
- **Progressive Enhancement**: Basic functionality works without JavaScript, enhanced with real-time features
- **Authentication Decorator**: Centralized access control using @require_auth decorator
- **RESTful API Design**: Consistent API endpoints for system operations and data retrieval
- **Responsive Design**: Mobile-first approach supporting desktop, tablet, and mobile access

### Security Considerations
- **Authentication System**: Username/password authentication with session management
- **Command Restrictions**: Whitelist of safe commands only (dir, ls, whoami, etc.)
- **File Upload Security**: Restricted file types and secure filename handling
- **Safe Log Paths**: Predefined list of accessible log files to prevent unauthorized file access
- **Error Handling**: Comprehensive exception handling to prevent information disclosure
- **Session Management**: Secure session secrets and timeout handling
- **Network Security**: Designed for trusted networks with firewall recommendations
- **Action Logging**: All administrative actions logged for audit trails
- **Cross-Platform Safety**: OS-specific command handling for secure system operations

## Recent Changes (July 26, 2025)
- ✅ Updated credentials to username: subhashbswkrm, password: Sb13579@@@
- ✅ Enhanced visual design with gradient themes and modern animations
- ✅ Rebranded to "RemoteLink Pro" with satellite dish icon
- ✅ Added live screen sharing with real-time screenshots
- ✅ Implemented mouse and keyboard control via web interface
- ✅ Created mobile QR code generation for easy device access
- ✅ Added attractive login page with animated background
- ✅ Enhanced dashboard with modern card hover effects
- ✅ Integrated Pillow for screenshot functionality
- ✅ Added QR code generation for cross-platform access
- ✅ Implemented mobile-friendly responsive design
- ✅ Added comprehensive authentication system with login/logout
- ✅ Implemented remote command execution with safety restrictions
- ✅ Created file manager for secure upload/download operations
- ✅ Added system power control (restart/shutdown/logout) with safety delays
- ✅ Enhanced security with @require_auth decorators on all admin functions
- ✅ Created Windows auto-startup batch scripts and Task Scheduler integration
- ✅ Added responsive design supporting desktop, mobile, and tablet access
- ✅ Implemented comprehensive documentation and security guidelines
- ✅ Added action history tracking and real-time command output display
- ✅ Created Advanced Threat Simulation interface for security testing
- ✅ Implemented data exfiltration simulation (system info, browser data, file search)
- ✅ Added stealth mode capabilities with anti-analysis features
- ✅ Built payload delivery simulation for penetration testing
- ✅ Enhanced persistence analysis with registry and scheduled task detection
- ✅ Added comprehensive activity logging for all security operations
- ✅ Rebranded Advanced Control as "Advanced Threat Simulation" with appropriate warnings
