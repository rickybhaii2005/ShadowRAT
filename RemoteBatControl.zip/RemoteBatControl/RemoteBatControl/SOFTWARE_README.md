# RemoteBatControl - Software Package

This document provides instructions for packaging, installing, and using the RemoteBatControl software.

## Packaging Instructions

### Prerequisites

- Windows operating system
- Python 3.7 or higher installed
- Internet connection (for downloading dependencies)

### Creating the Executable

1. **Run the packaging script**:
   - Double-click on `package_app.bat` in the RemoteBatControl directory
   - Choose one of the packaging options:
     - Option 1: Create a single executable file (recommended for easy distribution)
     - Option 2: Create a directory with executable and dependencies (better performance)
     - Option 3: Create a single executable with console window (useful for debugging)

2. **Wait for the packaging process to complete**:
   - The script will install necessary dependencies (including PyInstaller)
   - It will then package the application into an executable
   - The packaged software will be available in the `dist` directory

## Installation Instructions

### For End Users

1. **Copy the packaged software**:
   - If you chose Option 1 or 3: Copy the `RemoteBatControl.exe` file
   - If you chose Option 2: Copy the entire `RemoteBatControl` folder

2. **Run the application**:
   - Double-click on `RemoteBatControl.exe` to start the application
   - The application will start a web server on port 5000

3. **Access the web interface**:
   - Open a web browser and navigate to `http://localhost:5000`
   - Log in with the default credentials:
     - Username: `subhashbswkrm`
     - Password: `Sb13579@@@`

### Auto-Start Configuration

To configure the application to start automatically when the computer boots:

1. Create a shortcut to `RemoteBatControl.exe`
2. Press `Win + R`, type `shell:startup`, and press Enter
3. Move the shortcut to the Startup folder that opens

## Usage Instructions

### Dashboard

The dashboard provides an overview of system resources and status:

- CPU usage
- Memory consumption
- Disk space
- Network activity
- System information

### Remote Administration

The application provides several remote administration features:

- **Process Management**: View and manage running processes
- **File Management**: Upload, download, and manage files
- **Command Execution**: Execute safe system commands remotely
- **System Control**: Restart, shutdown, or log out of the system
- **Network Scanning**: Discover devices on the local network
- **Keylogger Deployment**: Deploy monitoring tools to target devices

### Security Considerations

- **Change default credentials**: Immediately change the default username and password
- **Network security**: Only use on trusted networks or behind a firewall
- **Permissions**: Ensure the application has appropriate permissions to function

## Troubleshooting

### Common Issues

1. **Application won't start**:
   - Ensure you have administrative privileges
   - Check if another application is using port 5000
   - Try running with the console window option to see error messages

2. **Can't access web interface**:
   - Verify the application is running (check Task Manager)
   - Ensure no firewall is blocking port 5000
   - Try accessing via IP address instead of localhost

3. **Features not working**:
   - Some features require administrative privileges
   - Certain operations may be blocked by system security policies

## Legal and Ethical Considerations

This software is designed for legitimate system administration and monitoring purposes. Using this software to monitor systems without proper authorization may violate privacy laws and regulations.

- Only use on systems you own or have explicit permission to monitor
- Inform users if their systems are being monitored
- Comply with all applicable laws and regulations regarding system monitoring

## Support

For support or questions, please refer to the project documentation or contact the developer.