import psutil
import platform
import os
import subprocess
import logging
import socket
import ipaddress
import threading
import queue
from datetime import datetime, timedelta
from typing import Dict, List, Any

class SystemMonitor:
    """System monitoring utility class"""
    
    def __init__(self):
        self.safe_log_paths = [
            '/var/log/syslog',
            '/var/log/messages',
            '/var/log/kern.log',
            '/var/log/auth.log',
            'C:\\Windows\\System32\\winevt\\Logs\\System.evtx',
            'C:\\Windows\\System32\\winevt\\Logs\\Application.evtx'
        ]
    
    def get_system_info(self) -> Dict[str, Any]:
        """Get basic system information"""
        try:
            boot_time = datetime.fromtimestamp(psutil.boot_time())
            uptime = datetime.now() - boot_time
            
            return {
                'hostname': platform.node(),
                'system': platform.system(),
                'release': platform.release(),
                'version': platform.version(),
                'machine': platform.machine(),
                'processor': platform.processor(),
                'boot_time': boot_time.strftime('%Y-%m-%d %H:%M:%S'),
                'uptime': str(uptime).split('.')[0],  # Remove microseconds
                'cpu_count': psutil.cpu_count(),
                'cpu_count_logical': psutil.cpu_count(logical=True)
            }
        except Exception as e:
            logging.error(f"Error getting system info: {e}")
            return {'error': str(e)}
    
    def get_system_stats(self) -> Dict[str, Any]:
        """Get real-time system statistics"""
        try:
            # CPU usage
            cpu_percent = psutil.cpu_percent(interval=1)
            cpu_per_core = psutil.cpu_percent(interval=1, percpu=True)
            
            # Memory usage
            memory = psutil.virtual_memory()
            swap = psutil.swap_memory()
            
            # Disk usage
            disk_usage = []
            for partition in psutil.disk_partitions():
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    disk_usage.append({
                        'device': partition.device,
                        'mountpoint': partition.mountpoint,
                        'fstype': partition.fstype,
                        'total': usage.total,
                        'used': usage.used,
                        'free': usage.free,
                        'percent': round((usage.used / usage.total) * 100, 2)
                    })
                except PermissionError:
                    continue
            
            # Load average (Unix-like systems only)
            load_avg = None
            if hasattr(os, 'getloadavg'):
                try:
                    load_avg = os.getloadavg()
                except:
                    pass
            
            return {
                'timestamp': datetime.now().isoformat(),
                'cpu': {
                    'percent': cpu_percent,
                    'per_core': cpu_per_core
                },
                'memory': {
                    'total': memory.total,
                    'available': memory.available,
                    'used': memory.used,
                    'percent': memory.percent
                },
                'swap': {
                    'total': swap.total,
                    'used': swap.used,
                    'free': swap.free,
                    'percent': swap.percent
                },
                'disk': disk_usage,
                'load_avg': load_avg
            }
        except Exception as e:
            logging.error(f"Error getting system stats: {e}")
            return {'error': str(e)}
    
    def get_processes(self) -> List[Dict[str, Any]]:
        """Get list of running processes"""
        try:
            processes = []
            for proc in psutil.process_iter(['pid', 'name', 'username', 'cpu_percent', 'memory_percent', 'status', 'create_time']):
                try:
                    proc_info = proc.info
                    proc_info['create_time'] = datetime.fromtimestamp(proc_info['create_time']).strftime('%Y-%m-%d %H:%M:%S')
                    processes.append(proc_info)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            # Sort by CPU usage
            processes.sort(key=lambda x: x.get('cpu_percent', 0), reverse=True)
            return processes[:50]  # Return top 50 processes
        except Exception as e:
            logging.error(f"Error getting processes: {e}")
            return []
    
    def get_network_info(self) -> Dict[str, Any]:
        """Get network interface information"""
        try:
            interfaces = {}
            net_if_addrs = psutil.net_if_addrs()
            net_if_stats = psutil.net_if_stats()
            
            for interface_name, addresses in net_if_addrs.items():
                interface_info = {
                    'addresses': [],
                    'stats': {}
                }
                
                # Get addresses
                for addr in addresses:
                    interface_info['addresses'].append({
                        'family': str(addr.family),
                        'address': addr.address,
                        'netmask': addr.netmask,
                        'broadcast': addr.broadcast
                    })
                
                # Get statistics
                if interface_name in net_if_stats:
                    stats = net_if_stats[interface_name]
                    interface_info['stats'] = {
                        'isup': stats.isup,
                        'duplex': str(stats.duplex),
                        'speed': stats.speed,
                        'mtu': stats.mtu
                    }
                
                interfaces[interface_name] = interface_info
            
            # Add discovered devices
            interfaces['discovered_devices'] = self.discover_network_devices()
            
            return interfaces
        except Exception as e:
            logging.error(f"Error getting network info: {e}")
            return {'error': str(e)}
            
    def discover_network_devices(self) -> List[Dict[str, Any]]:
        """Discover devices on the local network"""
        try:
            discovered_devices = []
            
            # Get local IP addresses to determine network ranges
            local_ips = []
            for interface, addrs in psutil.net_if_addrs().items():
                for addr in addrs:
                    # Only consider IPv4 addresses
                    if addr.family == socket.AF_INET and addr.address != '127.0.0.1':
                        local_ips.append({
                            'address': addr.address,
                            'netmask': addr.netmask,
                            'interface': interface
                        })
            
            if not local_ips:
                return discovered_devices
            
            # Function to scan a single IP
            def scan_ip(ip, result_queue):
                try:
                    # Check if host is reachable with ping
                    ping_param = '-n' if platform.system().lower() == 'windows' else '-c'
                    ping_cmd = ['ping', ping_param, '1', '-w', '500', ip]
                    ping_result = subprocess.run(ping_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=1)
                    is_reachable = ping_result.returncode == 0
                    
                    # Try to resolve hostname
                    try:
                        hostname = socket.gethostbyaddr(ip)[0]
                    except socket.herror:
                        hostname = "Unknown"
                    
                    # Check common ports
                    open_ports = []
                    common_ports = [80, 443, 22, 21, 3389, 5000, 8080]
                    for port in common_ports:
                        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        s.settimeout(0.5)  # Increased timeout for better reliability
                        result = s.connect_ex((ip, port))
                        s.close()
                        if result == 0:
                            open_ports.append(port)
                    
                    # Add device if it's reachable by ping, has open ports, or has a resolvable hostname
                    if is_reachable or open_ports or hostname != "Unknown":
                        result_queue.put({
                            'ip': ip,
                            'hostname': hostname,
                            'open_ports': open_ports,
                            'timestamp': datetime.now().isoformat(),
                            'status': 'active' if (is_reachable or open_ports) else 'detected'
                        })
                except Exception as e:
                    logging.debug(f"Error scanning IP {ip}: {e}")
            
            # Scan networks in parallel
            for local_ip in local_ips:
                try:
                    # Calculate network range from IP and netmask
                    ip_interface = ipaddress.IPv4Interface(f"{local_ip['address']}/{local_ip['netmask']}")
                    network = ip_interface.network
                    
                    # Use a queue to collect results from threads
                    result_queue = queue.Queue()
                    threads = []
                    
                    # Limit scan to first 255 IPs to avoid excessive scanning
                    ip_count = 0
                    for ip in network.hosts():
                        ip_str = str(ip)
                        ip_count += 1
                        if ip_count > 255:  # Limit to avoid scanning large networks
                            break
                            
                        # Skip the local IP
                        if ip_str == local_ip['address']:
                            continue
                            
                        # Create a thread for each IP
                        t = threading.Thread(target=scan_ip, args=(ip_str, result_queue))
                        t.daemon = True
                        threads.append(t)
                        t.start()
                        
                        # Limit number of concurrent threads
                        if len(threads) >= 100:  # Increased from 50 to 100 for faster scanning
                            # Wait for some threads to complete before adding more
                            for thread in threads:
                                thread.join(0.2)  # Reduced join timeout for faster scanning
                            threads = [t for t in threads if t.is_alive()]
                    
                    # Wait for remaining threads to complete
                    # Use a more efficient approach to wait for all threads
                    start_wait = datetime.now()
                    while threads and (datetime.now() - start_wait).total_seconds() < 10:  # Maximum 10 seconds wait
                        for thread in list(threads):
                            thread.join(0.2)
                            if not thread.is_alive():
                                threads.remove(thread)
                    
                    # Collect results
                    while not result_queue.empty():
                        discovered_devices.append(result_queue.get())
                except Exception as e:
                    logging.error(f"Error scanning network {network}: {e}")
            
            # Log the number of devices discovered for debugging
            logging.info(f"Network scan complete. Discovered {len(discovered_devices)} devices.")
            return discovered_devices
        except Exception as e:
            logging.error(f"Error discovering network devices: {e}")
            return []
    
    def get_network_stats(self) -> Dict[str, Any]:
        """Get network I/O statistics"""
        try:
            net_io = psutil.net_io_counters(pernic=True)
            connections = len(psutil.net_connections())
            
            stats = {}
            for interface, counters in net_io.items():
                stats[interface] = {
                    'bytes_sent': counters.bytes_sent,
                    'bytes_recv': counters.bytes_recv,
                    'packets_sent': counters.packets_sent,
                    'packets_recv': counters.packets_recv,
                    'errin': counters.errin,
                    'errout': counters.errout,
                    'dropin': counters.dropin,
                    'dropout': counters.dropout
                }
            
            return {
                'interfaces': stats,
                'connections': connections,
                'timestamp': datetime.now().isoformat()
            }
        except Exception as e:
            logging.error(f"Error getting network stats: {e}")
            return {'error': str(e)}
    
    def get_available_logs(self) -> List[str]:
        """Get list of available log files"""
        available_logs = []
        for log_path in self.safe_log_paths:
            if os.path.exists(log_path) and os.path.isfile(log_path):
                available_logs.append(log_path)
        return available_logs
    
    def get_log_content(self, log_file: str, lines: int = 100) -> str:
        """Get content from a log file (read-only, restricted access)"""
        if log_file not in self.safe_log_paths:
            raise ValueError("Access to this log file is not permitted")
        
        if not os.path.exists(log_file):
            raise FileNotFoundError(f"Log file {log_file} not found")
        
        try:
            with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
                # Read last N lines
                lines_list = f.readlines()
                if len(lines_list) > lines:
                    lines_list = lines_list[-lines:]
                return ''.join(lines_list)
        except Exception as e:
            logging.error(f"Error reading log file {log_file}: {e}")
            raise
    
    def get_service_status(self) -> List[Dict[str, Any]]:
        """Get status of common services (read-only)"""
        services = []
        common_services = [
            'ssh', 'sshd', 'nginx', 'apache2', 'httpd', 'mysql', 'postgresql',
            'docker', 'redis', 'mongodb', 'cron', 'rsyslog', 'NetworkManager'
        ]
        
        for service in common_services:
            try:
                # Check if service exists and get its status
                if platform.system() == 'Linux':
                    result = subprocess.run(
                        ['systemctl', 'is-active', service],
                        capture_output=True, text=True, timeout=5
                    )
                    status = result.stdout.strip()
                    
                    result_enabled = subprocess.run(
                        ['systemctl', 'is-enabled', service],
                        capture_output=True, text=True, timeout=5
                    )
                    enabled = result_enabled.stdout.strip()
                    
                    services.append({
                        'name': service,
                        'status': status,
                        'enabled': enabled,
                        'active': status == 'active'
                    })
                elif platform.system() == 'Windows':
                    # For Windows services
                    result = subprocess.run(
                        ['sc', 'query', service],
                        capture_output=True, text=True, timeout=5
                    )
                    if result.returncode == 0:
                        status = 'running' if 'RUNNING' in result.stdout else 'stopped'
                        services.append({
                            'name': service,
                            'status': status,
                            'enabled': 'unknown',
                            'active': status == 'running'
                        })
            except (subprocess.TimeoutExpired, subprocess.SubprocessError, FileNotFoundError):
                continue
        
        return services
