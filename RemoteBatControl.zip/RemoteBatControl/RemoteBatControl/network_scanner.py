import socket
import subprocess
import platform
import threading
import queue
import ipaddress
import logging
import time
from datetime import datetime
from typing import List, Dict, Any, Optional

class NetworkScanner:
    """Enhanced network scanner to discover all devices on the local network"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        # Common ports to scan for service detection
        self.common_ports = {
            21: "FTP",
            22: "SSH",
            23: "Telnet",
            25: "SMTP",
            53: "DNS",
            80: "HTTP",
            88: "Kerberos",
            110: "POP3",
            135: "RPC",
            139: "NetBIOS",
            143: "IMAP",
            389: "LDAP",
            443: "HTTPS",
            445: "SMB",
            636: "LDAPS",
            1433: "MSSQL",
            1521: "Oracle",
            3306: "MySQL",
            3389: "RDP",
            5000: "Flask",
            5432: "PostgreSQL",
            5900: "VNC",
            8080: "HTTP-Alt",
            8443: "HTTPS-Alt"
        }
        self.max_threads = 200  # Maximum number of concurrent threads
        self.timeout = 0.5  # Socket connection timeout in seconds
        self.ping_timeout = 1  # Ping timeout in seconds
    
    def get_local_networks(self) -> List[Dict[str, Any]]:
        """Get all local networks based on network interfaces"""
        local_networks = []
        
        try:
            import psutil
            # Get all network interfaces
            for interface, addrs in psutil.net_if_addrs().items():
                for addr in addrs:
                    # Only consider IPv4 addresses
                    if addr.family == socket.AF_INET and addr.address != '127.0.0.1':
                        try:
                            # Create network object from IP and netmask
                            ip_interface = ipaddress.IPv4Interface(f"{addr.address}/{addr.netmask}")
                            network = ip_interface.network
                            
                            local_networks.append({
                                'interface': interface,
                                'ip': addr.address,
                                'netmask': addr.netmask,
                                'network': str(network),
                                'network_obj': network
                            })
                        except Exception as e:
                            self.logger.error(f"Error processing network interface {interface}: {e}")
        except ImportError:
            # Fallback method if psutil is not available
            hostname = socket.gethostname()
            local_ip = socket.gethostbyname(hostname)
            
            # Assume a /24 network if we can't determine the netmask
            network = '.'.join(local_ip.split('.')[:3]) + '.0/24'
            network_obj = ipaddress.IPv4Network(network, strict=False)
            
            local_networks.append({
                'interface': 'default',
                'ip': local_ip,
                'netmask': '255.255.255.0',
                'network': network,
                'network_obj': network_obj
            })
            
        return local_networks
    
    def ping_host(self, ip: str) -> bool:
        """Check if host is reachable via ping"""
        try:
            # Use different ping parameters based on OS
            ping_param = '-n' if platform.system().lower() == 'windows' else '-c'
            ping_cmd = ['ping', ping_param, '1', '-w', '500', ip]
            
            # Run ping command with timeout
            result = subprocess.run(
                ping_cmd, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.PIPE, 
                timeout=self.ping_timeout
            )
            
            return result.returncode == 0
        except Exception as e:
            self.logger.debug(f"Error pinging {ip}: {e}")
            return False
    
    def get_hostname(self, ip: str) -> str:
        """Try to resolve hostname from IP address"""
        try:
            hostname = socket.gethostbyaddr(ip)[0]
            return hostname
        except (socket.herror, socket.gaierror):
            return "Unknown"
    
    def scan_port(self, ip: str, port: int) -> bool:
        """Check if a specific port is open"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(self.timeout)
            result = s.connect_ex((ip, port))
            s.close()
            return result == 0
        except Exception:
            return False
    
    def scan_device(self, ip: str, result_queue: queue.Queue):
        """Scan a single device for open ports and information"""
        try:
            # Check if host is reachable with ping
            is_reachable = self.ping_host(ip)
            
            # Try to resolve hostname
            hostname = self.get_hostname(ip)
            
            # Check common ports
            open_ports = []
            services = []
            
            for port, service_name in self.common_ports.items():
                if self.scan_port(ip, port):
                    open_ports.append(port)
                    services.append(f"{service_name} ({port})")
            
            # Determine device type based on open ports
            device_type = self.determine_device_type(open_ports)
            
            # Add device if it's reachable by ping, has open ports, or has a resolvable hostname
            if is_reachable or open_ports or hostname != "Unknown":
                result_queue.put({
                    'ip': ip,
                    'hostname': hostname,
                    'open_ports': open_ports,
                    'services': services,
                    'device_type': device_type,
                    'timestamp': datetime.now().isoformat(),
                    'status': 'active' if (is_reachable or open_ports) else 'detected'
                })
        except Exception as e:
            self.logger.debug(f"Error scanning device {ip}: {e}")
    
    def determine_device_type(self, open_ports: List[int]) -> str:
        """Determine device type based on open ports"""
        if not open_ports:
            return "Unknown"
        
        # Simple heuristics to guess device type
        if 80 in open_ports or 443 in open_ports:
            if 3389 in open_ports:
                return "Windows Server"
            elif 8080 in open_ports or 8443 in open_ports:
                return "Web Server"
            else:
                return "Web-enabled Device"
        
        if 22 in open_ports:
            if 5432 in open_ports:
                return "Database Server"
            else:
                return "Linux/Unix Device"
        
        if 445 in open_ports or 139 in open_ports:
            return "Windows Device"
        
        if 5900 in open_ports:
            return "VNC Server"
        
        if 3389 in open_ports:
            return "Windows/RDP Device"
        
        return "Network Device"
    
    def scan_network(self, network: Dict[str, Any], progress_callback=None) -> List[Dict[str, Any]]:
        """Scan a specific network for devices"""
        discovered_devices = []
        result_queue = queue.Queue()
        threads = []
        
        try:
            network_obj = network['network_obj']
            total_ips = sum(1 for _ in network_obj.hosts())
            scanned_ips = 0
            
            # Scan each IP in the network
            for ip in network_obj.hosts():
                ip_str = str(ip)
                
                # Skip the local IP
                if ip_str == network['ip']:
                    continue
                
                # Create a thread for each IP
                t = threading.Thread(target=self.scan_device, args=(ip_str, result_queue))
                t.daemon = True
                threads.append(t)
                t.start()
                
                scanned_ips += 1
                if progress_callback:
                    progress_callback(scanned_ips / total_ips * 100)
                
                # Limit number of concurrent threads
                if len(threads) >= self.max_threads:
                    # Wait for some threads to complete before adding more
                    for thread in threads.copy():
                        thread.join(0.1)
                        if not thread.is_alive():
                            threads.remove(thread)
            
            # Wait for remaining threads to complete
            start_wait = datetime.now()
            while threads and (datetime.now() - start_wait).total_seconds() < 30:  # Maximum 30 seconds wait
                for thread in threads.copy():
                    thread.join(0.2)
                    if not thread.is_alive():
                        threads.remove(thread)
                
                # Update progress while waiting
                if progress_callback:
                    # Calculate progress based on remaining threads
                    remaining = len(threads) / self.max_threads
                    progress = 100 - (remaining * 10)  # Adjust to show progress in final phase
                    progress_callback(min(99, progress))  # Cap at 99% until complete
            
            # Collect results
            while not result_queue.empty():
                discovered_devices.append(result_queue.get())
            
            # Final progress update
            if progress_callback:
                progress_callback(100)
            
        except Exception as e:
            self.logger.error(f"Error scanning network {network['network']}: {e}")
        
        return discovered_devices
    
    def scan_all_networks(self, progress_callback=None) -> Dict[str, Any]:
        """Scan all local networks for devices"""
        all_devices = []
        networks_info = []
        
        try:
            # Get all local networks
            local_networks = self.get_local_networks()
            
            if not local_networks:
                return {
                    'devices': [],
                    'networks': [],
                    'total_devices': 0,
                    'scan_time': 0
                }
            
            start_time = time.time()
            
            # Scan each network
            for i, network in enumerate(local_networks):
                self.logger.info(f"Scanning network {network['network']}")
                
                # Define a progress callback for this network
                def network_progress_callback(progress):
                    if progress_callback:
                        # Calculate overall progress based on network index
                        overall_progress = (i / len(local_networks) * 100) + (progress / len(local_networks))
                        progress_callback(overall_progress)
                
                # Scan the network
                devices = self.scan_network(network, network_progress_callback)
                all_devices.extend(devices)
                
                # Add network info
                networks_info.append({
                    'network': network['network'],
                    'interface': network['interface'],
                    'devices_count': len(devices)
                })
            
            scan_time = time.time() - start_time
            
            return {
                'devices': all_devices,
                'networks': networks_info,
                'total_devices': len(all_devices),
                'scan_time': round(scan_time, 2)
            }
            
        except Exception as e:
            self.logger.error(f"Error scanning networks: {e}")
            return {
                'error': str(e),
                'devices': [],
                'networks': [],
                'total_devices': 0,
                'scan_time': 0
            }

# Example usage
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scanner = NetworkScanner()
    
    def print_progress(progress):
        print(f"Scan progress: {progress:.1f}%")
    
    results = scanner.scan_all_networks(print_progress)
    
    print(f"\nScan completed in {results['scan_time']} seconds")
    print(f"Found {results['total_devices']} devices across {len(results['networks'])} networks")
    
    for network in results['networks']:
        print(f"Network: {network['network']} ({network['interface']}) - {network['devices_count']} devices")
    
    print("\nDiscovered devices:")
    for device in results['devices']:
        print(f"IP: {device['ip']} | Hostname: {device['hostname']} | Type: {device['device_type']} | Status: {device['status']}")
        if device['services']:
            print(f"  Services: {', '.join(device['services'])}")