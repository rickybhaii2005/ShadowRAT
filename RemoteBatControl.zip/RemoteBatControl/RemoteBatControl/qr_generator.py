#!/usr/bin/env python3
"""
QR Code Generator for RemoteLink Pro
Generates QR codes for easy mobile access to the remote control dashboard
"""

import qrcode
import socket
import os
from io import BytesIO
import base64

def get_local_ip():
    """Get the local IP address of the machine"""
    try:
        # Connect to a remote server to get local IP
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
        return local_ip
    except Exception:
        return "localhost"

def generate_access_qr(port=5000, username="subhashbswkrm", password="Sb13579@@@"):
    """Generate QR code for mobile access"""
    local_ip = get_local_ip()
    
    # Create the access URL
    access_url = f"http://{local_ip}:{port}"
    
    # Create QR code
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(access_url)
    qr.make(fit=True)
    
    # Create QR code image
    img = qr.make_image(fill_color="black", back_color="white")
    
    # Convert to base64 for web display
    buffer = BytesIO()
    img.save(buffer, format='PNG')
    qr_b64 = base64.b64encode(buffer.getvalue()).decode()
    
    return {
        'qr_code': qr_b64,
        'access_url': access_url,
        'local_ip': local_ip,
        'username': username,
        'password': password
    }

def create_mobile_instructions():
    """Create mobile access instructions"""
    data = generate_access_qr()
    
    instructions = f"""
📱 MOBILE ACCESS SETUP - RemoteLink Pro
==========================================

🌐 NETWORK ACCESS:
   URL: {data['access_url']}
   IP:  {data['local_ip']}:5000

🔐 LOGIN CREDENTIALS:
   Username: {data['username']}
   Password: {data['password']}

📋 SETUP INSTRUCTIONS:

FOR ANDROID/MOBILE:
1. Scan the QR code below with your phone camera
2. Open the link in your mobile browser
3. Login with the credentials above
4. Add to home screen for quick access

FOR WINDOWS/DESKTOP:
1. Open browser and go to: {data['access_url']}
2. Login with credentials above
3. Bookmark for easy access

⚡ FEATURES AVAILABLE ON MOBILE:
✓ Real-time system monitoring
✓ Remote command execution
✓ File upload/download
✓ Live screen view with touch control
✓ Mouse and keyboard control
✓ System power control (restart/shutdown)
✓ Process and network monitoring
✓ System log viewing

🔒 SECURITY NOTES:
- Only use on trusted networks
- Change default credentials for production
- Enable firewall restrictions as needed
- All actions are logged for security

==========================================
Scan QR code below with mobile device:
"""
    
    return instructions, data

if __name__ == "__main__":
    instructions, data = create_mobile_instructions()
    print(instructions)
    
    # Save QR code as file
    qr_code_data = base64.b64decode(data['qr_code'])
    with open('mobile_access_qr.png', 'wb') as f:
        f.write(qr_code_data)
    
    print(f"\nQR code saved as 'mobile_access_qr.png'")
    print(f"Access URL: {data['access_url']}")